'use client';

/**
 * FinaleSection
 * -------------
 * Dignified closing memorial vow.
 * Includes interactive virtual memorial candle lighting and closing tribute.
 */

import { useState } from 'react';
import { motion } from 'framer-motion';

export default function FinaleSection() {
  const [candlesCount, setCandlesCount] = useState(14820);
  const [hasLit, setHasLit] = useState(false);

  const lightCandle = () => {
    if (!hasLit) {
      setCandlesCount((c) => c + 1);
      setHasLit(true);
    }
  };

  return (
    <section
      id="finale"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
        padding: '120px 24px 80px',
        textAlign: 'center',
        direction: 'rtl',
      }}
    >
      <div
        style={{
          maxWidth: '850px',
          width: '100%',
          background: 'rgba(10, 15, 26, 0.85)',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          borderRadius: '32px',
          padding: '64px 32px',
          backdropFilter: 'blur(20px)',
          boxShadow: '0 30px 80px rgba(0,0,0,0.8), 0 0 40px rgba(245, 158, 11, 0.1)',
        }}
      >
        {/* Virtual Memorial Candle */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '36px' }}>
          {/* Candle Flame */}
          <div
            className="animate-flame"
            style={{
              width: '16px',
              height: '32px',
              background: 'radial-gradient(ellipse at 50% 80%, #ffffff 0%, #fef08a 40%, #f59e0b 80%, #ef4444 100%)',
              borderRadius: '50% 50% 35% 35% / 60% 60% 40% 40%',
              boxShadow: '0 0 20px #f59e0b, 0 0 40px #fbbf24',
              marginBottom: '2px',
            }}
          />
          {/* Candle Body */}
          <div
            style={{
              width: '12px',
              height: '42px',
              background: 'linear-gradient(180deg, #fef3c7 0%, #d97706 100%)',
              borderRadius: '4px 4px 2px 2px',
              opacity: 0.9,
            }}
          />

          <button
            onClick={lightCandle}
            style={{
              marginTop: '20px',
              background: hasLit
                ? 'rgba(245, 158, 11, 0.15)'
                : 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
              color: hasLit ? '#fbbf24' : '#000000',
              border: hasLit ? '1px solid #f59e0b' : 'none',
              borderRadius: '999px',
              padding: '10px 24px',
              fontSize: '13px',
              fontWeight: 700,
              cursor: hasLit ? 'default' : 'pointer',
              boxShadow: hasLit ? 'none' : '0 4px 20px rgba(245, 158, 11, 0.4)',
              transition: 'all 0.3s ease',
            }}
          >
            {hasLit ? '✦ أُضيئت شمعتك في الذاكرة' : '🕯️ أشعل شمعة تخليدًا لذكراهم'}
          </button>

          <span style={{ fontSize: '11px', color: '#94a3b8', marginTop: '8px' }}>
            {candlesCount.toLocaleString('ar-EG')} شمعة أُضيئت تخليدًا للشهداء
          </span>
        </div>

        {/* Closing Vow */}
        <h2
          style={{
            fontSize: 'clamp(2rem, 5vw, 3.6rem)',
            fontWeight: 800,
            color: '#f8fafc',
            lineHeight: 1.3,
            marginBottom: '16px',
            letterSpacing: '-0.02em',
          }}
        >
          لم يكونوا أرقامًا... ولن يُنسوا
        </h2>

        <p
          style={{
            fontSize: '16px',
            color: '#cbd5e1',
            lineHeight: 1.8,
            maxWidth: '650px',
            margin: '0 auto 36px',
          }}
        >
          تظل أسماؤهم حية في قلوبنا، وشهادةً على حقهم في الحياة والحرية والكرامة. كل اسمٍ في هذا السجل باقٍ ما بقي الأمل وما عاشت فلسطين.
        </p>

        {/* Flag Bar */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            height: '4px',
            width: '140px',
            margin: '0 auto 28px',
            borderRadius: '2px',
            overflow: 'hidden',
          }}
        >
          <div style={{ flex: 1, background: '#000000' }} />
          <div style={{ flex: 1, background: '#ffffff' }} />
          <div style={{ flex: 1, background: '#006233' }} />
          <div style={{ flex: 1, background: '#CE1126' }} />
        </div>

        {/* Source Citation */}
        <div style={{ fontSize: '11px', color: '#64748b' }}>
          سجل الضحايا الفلسطينيين · وزارة الصحة الفلسطينية — قطاع غزة · {new Date().getFullYear()}
        </div>
      </div>
    </section>
  );
}
