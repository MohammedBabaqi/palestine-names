'use client';

/**
 * HeroSection
 * -----------
 * Monumental opening scene in deep dark space.
 * Features a glowing numeric count-up to 72,835 with radial celestial bloom.
 * Key takeaway: "لم يكونوا أرقامًا... بل كانوا أرواحًا وحكايات"
 */

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const TARGET = 72835;

function useCountUp(target: number, duration = 2200) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    const start = performance.now();
    let raf: number;
    const tick = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      setCount(Math.round(eased * target));
      if (progress < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return count;
}

export default function HeroSection() {
  const count = useCountUp(TARGET);
  const formatted = count.toLocaleString('en-US');

  return (
    <section
      id="hero"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '120px 24px 80px',
        zIndex: 10,
        textAlign: 'center',
        direction: 'rtl',
      }}
    >
      {/* Subtle Central Radiant Glow */}
      <div
        style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: 'clamp(300px, 60vw, 700px)',
          height: 'clamp(300px, 60vw, 700px)',
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.12) 0%, rgba(6, 78, 59, 0.05) 50%, transparent 70%)',
          filter: 'blur(40px)',
          pointerEvents: 'none',
          zIndex: -1,
        }}
      />

      {/* Palestinian Memory Badge */}
      <motion.div
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '8px',
          padding: '6px 18px',
          background: 'rgba(15, 23, 42, 0.8)',
          border: '1px solid rgba(16, 185, 129, 0.35)',
          borderRadius: '999px',
          marginBottom: '24px',
          boxShadow: '0 4px 20px rgba(0,0,0,0.5), 0 0 15px rgba(16, 185, 129, 0.2)',
        }}
      >
        <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#10b981', boxShadow: '0 0 8px #10b981' }} />
        <span style={{ fontSize: '12px', fontWeight: 600, color: '#34d399', letterSpacing: '0.05em' }}>
          أرشيف الذاكرة الوطنية الفلسطينية
        </span>
      </motion.div>

      {/* Monumental Glowing Number */}
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        style={{
          fontSize: 'clamp(70px, 16vw, 200px)',
          fontWeight: 800,
          lineHeight: 0.95,
          fontFamily: "'IBM Plex Sans Arabic', sans-serif",
          fontVariantNumeric: 'tabular-nums',
          letterSpacing: '-0.03em',
          background: 'linear-gradient(180deg, #ffffff 30%, #94a3b8 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          filter: 'drop-shadow(0 0 35px rgba(255, 255, 255, 0.18))',
          userSelect: 'none',
        }}
      >
        {formatted}
      </motion.div>

      {/* Emotional Core Title */}
      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.3 }}
        style={{
          fontSize: 'clamp(1.4rem, 3.5vw, 2.5rem)',
          fontWeight: 700,
          color: '#f8fafc',
          marginTop: '20px',
          maxWidth: '800px',
          lineHeight: 1.4,
        }}
      >
        لم يكونوا أرقامًا... بل كانوا أرواحًا وأحلامًا وعائلات
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.9, delay: 0.5 }}
        style={{
          fontSize: 'clamp(0.95rem, 1.8vw, 1.2rem)',
          color: '#94a3b8',
          maxWidth: '650px',
          marginTop: '12px',
          lineHeight: 1.7,
        }}
      >
        سجلٌ رقمي تفاعلي يخلّد أسماء شهداء غزة الأبرار، موثقًا كل روحٍ ومستحضرًا حضورها الدائم في ضمير الإنسانية.
      </motion.p>

      {/* Metric Quick Stats Badges */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.7 }}
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          gap: '14px',
          marginTop: '36px',
        }}
      >
        <div
          style={{
            background: 'rgba(15, 23, 42, 0.7)',
            border: '1px solid rgba(245, 158, 11, 0.3)',
            borderRadius: '14px',
            padding: '10px 20px',
            backdropFilter: 'blur(10px)',
          }}
        >
          <span style={{ fontSize: '11px', color: '#94a3b8' }}>الأطفال المستشهدون: </span>
          <strong style={{ fontSize: '14px', color: '#fbbf24' }}>21,637 طفلًا</strong>
        </div>

        <div
          style={{
            background: 'rgba(15, 23, 42, 0.7)',
            border: '1px solid rgba(16, 185, 129, 0.3)',
            borderRadius: '14px',
            padding: '10px 20px',
            backdropFilter: 'blur(10px)',
          }}
        >
          <span style={{ fontSize: '11px', color: '#94a3b8' }}>متوسط الأعمار: </span>
          <strong style={{ fontSize: '14px', color: '#34d399' }}>28.7 سنة</strong>
        </div>

        <div
          style={{
            background: 'rgba(15, 23, 42, 0.7)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            borderRadius: '14px',
            padding: '10px 20px',
            backdropFilter: 'blur(10px)',
          }}
        >
          <span style={{ fontSize: '11px', color: '#94a3b8' }}>المصدر: </span>
          <strong style={{ fontSize: '12px', color: '#e2e8f0' }}>وزارة الصحة الفلسطينية</strong>
        </div>
      </motion.div>

      {/* Animated Scroll Invitation */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        onClick={() => {
          const el = document.getElementById('names');
          if (el) {
            const top = el.getBoundingClientRect().top + window.scrollY - 70;
            window.scrollTo({ top, behavior: 'smooth' });
          }
        }}
        style={{
          marginTop: '50px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '10px',
          cursor: 'pointer',
          userSelect: 'none',
        }}
      >
        <span style={{ fontSize: '11px', color: '#94a3b8', letterSpacing: '0.1em' }}>
          انزل لاستكشاف سماء الأسماء ↓
        </span>
        <div
          style={{
            width: '24px',
            height: '40px',
            borderRadius: '16px',
            border: '2px solid rgba(255, 255, 255, 0.2)',
            display: 'flex',
            justifyContent: 'center',
            paddingTop: '6px',
          }}
        >
          <motion.div
            animate={{ y: [0, 14, 0] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
            style={{
              width: '4px',
              height: '8px',
              borderRadius: '2px',
              background: '#10b981',
              boxShadow: '0 0 6px #10b981',
            }}
          />
        </div>
      </motion.div>
    </section>
  );
}
