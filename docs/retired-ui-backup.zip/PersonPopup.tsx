'use client';

/**
 * PersonPopup
 * -----------
 * Elegant floating paper label emerging from the crowd.
 * Styled as an archival paper slip with thin typography, delicate hairline border,
 * and warm, respectful presentation.
 */

import { useEffect, useRef } from 'react';
import { Html } from '@react-three/drei';
import type { Record } from '@/lib/types';

interface PersonPopupProps {
  record: Record;
  position: [number, number, number];
}

export default function PersonPopup({ record, position }: PersonPopupProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.style.opacity = '0';
    el.style.transform = 'translateY(6px) scale(0.96)';
    const raf = requestAnimationFrame(() => {
      el.style.transition = 'all 0.28s cubic-bezier(0.16, 1, 0.3, 1)';
      el.style.opacity = '1';
      el.style.transform = 'translateY(0) scale(1)';
    });
    return () => cancelAnimationFrame(raf);
  }, [record.id]);

  const isChild = record.age !== null && record.age !== undefined && record.age < 18;
  const sexLabel = record.sex === 'm' ? 'ذكر' : record.sex === 'f' ? 'أنثى' : null;

  return (
    <Html
      position={position}
      style={{ pointerEvents: 'none' }}
      center
      distanceFactor={6.5}
    >
      <div
        ref={containerRef}
        style={{
          background: '#FFFDF9',
          border: '1px solid #DCD6C8',
          boxShadow: '0 8px 24px rgba(45, 38, 25, 0.12), 0 2px 6px rgba(45, 38, 25, 0.05)',
          borderRadius: '6px',
          padding: '10px 14px',
          minWidth: '160px',
          maxWidth: '220px',
          fontFamily: "'IBM Plex Sans Arabic', sans-serif",
          direction: 'rtl',
          textAlign: 'right',
          position: 'relative',
        }}
      >
        {/* Child indicator minimal badge */}
        {isChild && (
          <div
            style={{
              display: 'inline-block',
              background: 'rgba(197, 34, 40, 0.08)',
              color: '#C52228',
              border: '1px solid rgba(197, 34, 40, 0.2)',
              fontSize: '9.5px',
              fontWeight: 600,
              padding: '1px 6px',
              borderRadius: '3px',
              marginBottom: '4px',
            }}
          >
            طفل
          </div>
        )}

        {/* Name */}
        <div
          style={{
            fontSize: '13.5px',
            fontWeight: 700,
            color: '#1C1C1A',
            lineHeight: 1.35,
            marginBottom: '6px',
          }}
        >
          {record.ar_name || record.en_name || 'شهيد مجهول الاسم'}
        </div>

        {/* Metadata Details in thin ink typography */}
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '3px',
            borderTop: '1px solid #EFEAE0',
            paddingTop: '6px',
            fontSize: '11px',
            color: '#6E6B64',
          }}
        >
          {record.age !== null && record.age !== undefined && (
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>العمر:</span>
              <span style={{ fontWeight: 600, color: '#1C1C1A' }}>{record.age} عامًا</span>
            </div>
          )}

          {sexLabel && (
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>الجنس:</span>
              <span style={{ color: '#3D3D3A' }}>{sexLabel}</span>
            </div>
          )}

          {record.dob && (
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span>الميلاد:</span>
              <span style={{ color: '#73716B', direction: 'ltr' }}>{record.dob.slice(0, 4)}</span>
            </div>
          )}

          {record.id && (
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '2px' }}>
              <span>السجل:</span>
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '10px', color: '#0E5C36' }}>
                #{record.id}
              </span>
            </div>
          )}
        </div>
      </div>
    </Html>
  );
}
