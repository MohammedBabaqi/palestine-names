'use client';

/**
 * ArchivistSection — حارس الأرشيف
 * --------------------------------
 * The AI Archivist character. Rule-based intent detection (no API key needed).
 * Archival paper aesthetic: parchment background, typewriter input,
 * floating paper-slip suggestions.
 * AnimatedBeam shows query → processing connection.
 */

import { useState, useRef, useCallback, useEffect } from 'react';
import AnimatedBeam from '@/components/ui/AnimatedBeam';
import BlurFade from '@/components/ui/BlurFade';
import { api } from '@/lib/api';
import { useParticleStore } from '@/lib/particleStore';

// ─── Intent Detection ──────────────────────────────────────────────────────────

type ToolName =
  | 'SEARCH_BY_NAME' | 'SEARCH_BY_AGE' | 'SEARCH_BY_DATE'
  | 'SORT_BY_NAME' | 'SORT_BY_AGE' | 'SORT_BY_DATE'
  | 'GET_STATISTICS' | 'GET_AVERAGE_AGE' | 'GET_MEDIAN_AGE'
  | 'GET_RECORD_COUNT' | 'GET_CHILDREN_COUNT' | 'GET_YOUNGEST' | 'GET_OLDEST'
  | 'UNKNOWN';

interface Intent {
  tool: ToolName;
  params: Record<string, any>;
  confidence: number;
}

function detectIntent(query: string): Intent {
  const q = query.trim();
  if (/ابحث عن|اعثر على|هل يوجد|هل توجد/.test(q)) {
    const nameMatch = q.match(/(?:ابحث عن|اعثر على|هل يوجد|هل توجد)\s+(.+)/);
    return { tool: 'SEARCH_BY_NAME', params: { name: nameMatch?.[1]?.trim() || q }, confidence: 0.9 };
  }
  if (/متوسط|معدل/.test(q) && /عمر|أعمار/.test(q))
    return { tool: 'GET_AVERAGE_AGE', params: {}, confidence: 0.95 };
  if (/وسيط|وسط/.test(q))
    return { tool: 'GET_MEDIAN_AGE', params: {}, confidence: 0.95 };
  if (/أصغر|أقل عمرًا|أصغر شخص/.test(q))
    return { tool: 'GET_YOUNGEST', params: {}, confidence: 0.9 };
  if (/أكبر|أكثر عمرًا|أكبر شخص/.test(q))
    return { tool: 'GET_OLDEST', params: {}, confidence: 0.9 };
  if (/أطفال|طفل|أقل من 18|دون ال/.test(q))
    return { tool: 'GET_CHILDREN_COUNT', params: {}, confidence: 0.9 };
  if (/عدد السجلات|كم سجل|إجمالي|كم عدد/.test(q) && !/أطفال/.test(q))
    return { tool: 'GET_RECORD_COUNT', params: {}, confidence: 0.85 };
  if (/إحصاء|إحصائيات|معلومات عامة|بيانات/.test(q))
    return { tool: 'GET_STATISTICS', params: {}, confidence: 0.8 };
  if (/رتّب|ترتيب|رتب/.test(q)) {
    if (/اسم/.test(q)) return { tool: 'SORT_BY_NAME', params: { ascending: !/تنازلي/.test(q) }, confidence: 0.9 };
    if (/عمر/.test(q)) return { tool: 'SORT_BY_AGE', params: { ascending: !/تنازلي/.test(q) }, confidence: 0.9 };
    if (/تاريخ/.test(q)) return { tool: 'SORT_BY_DATE', params: { ascending: !/تنازلي/.test(q) }, confidence: 0.9 };
    return { tool: 'SORT_BY_NAME', params: { ascending: true }, confidence: 0.5 };
  }
  const ageMatch = q.match(/(?:عمر|أعمار?)\s*(\d+)/);
  if (ageMatch) return { tool: 'SEARCH_BY_AGE', params: { age: parseInt(ageMatch[1]) }, confidence: 0.85 };
  if (/[ء-ي]{3,}/.test(q)) return { tool: 'SEARCH_BY_NAME', params: { name: q }, confidence: 0.6 };
  return { tool: 'UNKNOWN', params: {}, confidence: 0 };
}

async function executeTool(intent: Intent): Promise<{ data: any; label: string }> {
  const { tool, params } = intent;
  switch (tool) {
    case 'SEARCH_BY_NAME': return { data: await api.searchByName(params.name, 1, 10), label: 'SEARCH_BY_NAME' };
    case 'SEARCH_BY_AGE': return { data: await api.searchByAge(params.age, 2, 1, 10), label: 'SEARCH_BY_AGE' };
    case 'SORT_BY_NAME': return { data: await api.sortByName(params.ascending ?? true, 1, 10), label: 'SORT_BY_NAME' };
    case 'SORT_BY_AGE': return { data: await api.sortByAge(params.ascending ?? true, 1, 10), label: 'SORT_BY_AGE' };
    case 'SORT_BY_DATE': return { data: await api.sortByDate(params.ascending ?? true, 1, 10), label: 'SORT_BY_DATE' };
    case 'GET_STATISTICS': case 'GET_AVERAGE_AGE': case 'GET_MEDIAN_AGE':
    case 'GET_RECORD_COUNT': case 'GET_CHILDREN_COUNT': case 'GET_YOUNGEST': case 'GET_OLDEST':
      return { data: await api.getStatistics(), label: tool };
    default: return { data: null, label: 'UNKNOWN' };
  }
}

function generateResponse(intent: Intent, toolResult: any): string {
  const { tool } = intent;
  const data = toolResult.data;
  if (!data) return 'عذرًا، لم أتمكن من فهم سؤالك. جرّب: "ابحث عن محمد" أو "كم متوسط الأعمار؟"';
  switch (tool) {
    case 'SEARCH_BY_NAME':
      return data.count === 0
        ? `لم أجد أي سجل يطابق "${intent.params.name}".`
        : `وجدتُ ${data.count?.toLocaleString()} سجلًا يطابق "${intent.params.name}". إليك أول النتائج:`;
    case 'SEARCH_BY_AGE': return `وجدتُ ${data.count?.toLocaleString()} سجلًا في نطاق العمر ${intent.params.age} سنة.`;
    case 'SORT_BY_NAME': return `رتّبتُ السجلات أبجديًا باستخدام ${data.algorithm || 'Merge Sort'}. إليك أول النتائج:`;
    case 'SORT_BY_AGE': return `رتّبتُ السجلات حسب العمر. إليك أصغر الأعمار:`;
    case 'SORT_BY_DATE': return `رتّبتُ السجلات حسب تاريخ الميلاد.`;
    case 'GET_AVERAGE_AGE': return `متوسط الأعمار في الأرشيف هو ${data.average_age} عامًا — محسوبًا على ${data.total_with_age?.toLocaleString()} سجلًا.`;
    case 'GET_MEDIAN_AGE': return `الوسيط العمري هو ${data.median_age} عامًا.`;
    case 'GET_RECORD_COUNT': return `يضمّ الأرشيف ${data.total?.toLocaleString()} سجلًا.`;
    case 'GET_CHILDREN_COUNT': return `عدد الأطفال (أقل من ١٨ عامًا): ${data.children_under_18?.toLocaleString()} طفلًا.`;
    case 'GET_YOUNGEST': return `أصغر سجل في الأرشيف: ${data.min_age} أعوام.`;
    case 'GET_OLDEST': return `أكبر سجل في الأرشيف: ${data.max_age} عامًا.`;
    case 'GET_STATISTICS': return `إحصائيات الأرشيف: ${data.total?.toLocaleString()} سجل، متوسط العمر ${data.average_age} عامًا، منهم ${data.children_under_18?.toLocaleString()} طفلًا.`;
    default: return 'عذرًا، لم أتمكن من معالجة هذا الطلب.';
  }
}

// ─── Suggested questions ────────────────────────────────────────────────────────
const SUGGESTIONS = [
  'كم متوسط الأعمار؟',
  'من أصغر الأشخاص؟',
  'كم عدد الأطفال؟',
  'ابحث عن محمد',
  'رتّب الأسماء أبجديًا',
  'رتّب حسب العمر',
  'كم عدد السجلات؟',
  'من أكبر الأشخاص؟',
];

interface Message {
  id: number;
  role: 'user' | 'archivist';
  text: string;
  tool?: string;
  records?: any[];
  timestamp: Date;
}

let msgId = 0;

export default function ArchivistSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLDivElement>(null);
  const archivistRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: 'archivist',
      text: 'مرحبًا. أنا حارس الأرشيف.\n\nأنا لا أحفظ الأرقام. أنا أبحث عن الأسماء.\n\nاسألني أي شيء عن هذا الأرشيف.',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const { setHighlightIds, setSortMode } = useParticleStore();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || thinking) return;
    setMessages((prev) => [...prev, { id: ++msgId, role: 'user', text: text.trim(), timestamp: new Date() }]);
    setInput('');
    setThinking(true);

    try {
      const intent = detectIntent(text.trim());
      const toolResult = await executeTool(intent);
      const responseText = generateResponse(intent, toolResult);

      // Sync particle field with results
      if (intent.tool === 'SEARCH_BY_NAME' && toolResult.data?.results) {
        setHighlightIds(toolResult.data.results.map((r: any) => r.id));
      }
      if (intent.tool === 'SORT_BY_AGE') setSortMode('age', true);
      if (intent.tool === 'SORT_BY_NAME') setSortMode('name', true);

      setMessages((prev) => [...prev, {
        id: ++msgId,
        role: 'archivist',
        text: responseText,
        tool: toolResult.label !== 'UNKNOWN' ? toolResult.label : undefined,
        records: toolResult.data?.results?.slice(0, 6),
        timestamp: new Date(),
      }]);
    } catch {
      setMessages((prev) => [...prev, {
        id: ++msgId,
        role: 'archivist',
        text: 'حدث خطأ. هل الخادم يعمل على المنفذ 8000؟',
        timestamp: new Date(),
      }]);
    } finally {
      setThinking(false);
    }
  }, [thinking, setHighlightIds, setSortMode]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  }, [input, sendMessage]);

  return (
    <section
      ref={sectionRef}
      id="archivist"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        zIndex: 10,
        background: 'rgba(253,250,245,0.97)',
        borderTop: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'stretch',
        justifyContent: 'center',
        padding: '80px 24px',
      }}
    >
      <div style={{ width: '100%', maxWidth: 860 }}>
        {/* Header */}
        <BlurFade duration={0.8} inView>
          <div style={{ marginBottom: 48, direction: 'rtl' }}>
            <div className="section-label" style={{ marginBottom: 12 }}>AI archivist — حارس الأرشيف</div>
            <div className="section-title-ar">حارس الأرشيف</div>
            <div style={{
              fontFamily: 'var(--font-arabic)',
              fontSize: '0.95rem',
              color: 'var(--text-muted)',
              marginTop: 8,
              maxWidth: 400,
              lineHeight: 1.8,
            }}>
              لا يحفظ الأرقام. يبحث عن الأسماء.
            </div>
          </div>
        </BlurFade>

        {/* Main layout */}
        <div
          ref={containerRef}
          style={{ position: 'relative', display: 'flex', gap: 32, alignItems: 'flex-start' }}
        >
          {/* Archivist avatar */}
          <BlurFade delay={0.2} duration={0.8} inView>
            <div
              ref={archivistRef}
              style={{
                flexShrink: 0,
                width: 80,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: 8,
                paddingTop: 8,
              }}
            >
              {/* Stylized archivist figure */}
              <div style={{
                width: 56,
                height: 56,
                borderRadius: '50%',
                background: 'var(--bg-parchment)',
                border: '2px solid var(--border-medium)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '24px',
              }}>
                📜
              </div>
              <div style={{
                fontFamily: 'var(--font-arabic)',
                fontSize: '10px',
                color: 'var(--text-muted)',
                direction: 'rtl',
                textAlign: 'center',
                lineHeight: 1.4,
              }}>
                حارس<br />الأرشيف
              </div>
              {thinking && (
                <div style={{
                  width: 6,
                  height: 6,
                  borderRadius: '50%',
                  background: 'var(--accent-green)',
                  animation: 'pulse 1s ease-in-out infinite',
                }} />
              )}
            </div>
          </BlurFade>

          {/* Conversation + input */}
          <div style={{ flex: 1, minWidth: 0 }}>
            {/* Messages */}
            <div style={{
              minHeight: 200,
              maxHeight: '50vh',
              overflowY: 'auto',
              marginBottom: 24,
              padding: '20px 0',
            }}>
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  style={{
                    marginBottom: 20,
                    direction: 'rtl',
                    display: 'flex',
                    justifyContent: msg.role === 'user' ? 'flex-start' : 'flex-end',
                  }}
                >
                  <div style={{
                    maxWidth: '80%',
                    padding: '12px 16px',
                    background: msg.role === 'user'
                      ? 'var(--bg-paper)'
                      : 'var(--bg-parchment)',
                    border: `1px solid ${msg.role === 'user' ? 'var(--border-light)' : 'var(--border-medium)'}`,
                    position: 'relative',
                  }}>
                    {/* Message text */}
                    <div style={{
                      fontFamily: 'var(--font-arabic)',
                      fontSize: '0.95rem',
                      color: 'var(--text-primary)',
                      lineHeight: 1.8,
                      whiteSpace: 'pre-line',
                    }}>
                      {msg.text}
                    </div>

                    {/* Tool badge */}
                    {msg.tool && (
                      <div style={{ marginTop: 10, display: 'flex', gap: 8, alignItems: 'center' }}>
                        <span className="algorithm-badge green">{msg.tool.replace(/_/g, ' ')}</span>
                      </div>
                    )}

                    {/* Result records */}
                    {msg.records && msg.records.length > 0 && (
                      <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 4 }}>
                        {msg.records.map((r: any, i: number) => (
                          <div
                            key={i}
                            style={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              padding: '6px 10px',
                              borderBottom: '1px solid var(--border-subtle)',
                              fontFamily: 'var(--font-arabic)',
                              fontSize: '0.875rem',
                              direction: 'rtl',
                              gap: 12,
                            }}
                          >
                            <span style={{ fontWeight: 500, color: 'var(--text-primary)' }}>
                              {r.ar_name || r.en_name}
                            </span>
                            <span style={{
                              fontFamily: 'var(--font-mono)',
                              fontSize: '10px',
                              color: 'var(--text-muted)',
                            }}>
                              {r.age !== null && r.age !== undefined ? `${r.age}y` : ''}
                              {r.sex ? ` · ${r.sex === 'm' ? 'M' : 'F'}` : ''}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {/* Thinking indicator */}
              {thinking && (
                <div style={{ display: 'flex', justifyContent: 'flex-end', direction: 'rtl' }}>
                  <div style={{
                    padding: '10px 16px',
                    background: 'var(--bg-parchment)',
                    border: '1px solid var(--border-medium)',
                    display: 'flex',
                    gap: 6,
                    alignItems: 'center',
                  }}>
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        style={{
                          width: 5,
                          height: 5,
                          borderRadius: '50%',
                          background: 'var(--text-muted)',
                          animation: `dotBounce 1.2s ease-in-out ${i * 0.2}s infinite`,
                        }}
                      />
                    ))}
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input area — typewriter style */}
            <div ref={inputRef}>
              <div className="typewriter-container">
                <textarea
                  ref={textareaRef}
                  className="typewriter-input"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="اسأل حارس الأرشيف..."
                  rows={3}
                  disabled={thinking}
                />
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginTop: 12,
                }}>
                  <div style={{
                    fontFamily: 'var(--font-mono)',
                    fontSize: '9px',
                    color: 'var(--text-faint)',
                    letterSpacing: '0.15em',
                    textTransform: 'uppercase',
                  }}>
                    Enter to send · Shift+Enter for new line
                  </div>
                  <button
                    onClick={() => sendMessage(input)}
                    disabled={!input.trim() || thinking}
                    className="btn-accent"
                    style={{ fontSize: '10px', padding: '6px 16px' }}
                  >
                    إرسال
                  </button>
                </div>
              </div>

              {/* AnimatedBeam: input → archivist when thinking */}
              {thinking && (
                <AnimatedBeam
                  containerRef={containerRef}
                  fromRef={inputRef}
                  toRef={archivistRef}
                  curvature={-50}
                  reverse
                  duration={2}
                  pathWidth={1.5}
                  gradientStopColor="var(--accent-green)"
                />
              )}
            </div>

            {/* Suggested questions as paper slips */}
            <div style={{ marginTop: 24, direction: 'rtl' }}>
              <div style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '9px',
                letterSpacing: '0.2em',
                textTransform: 'uppercase',
                color: 'var(--text-faint)',
                marginBottom: 12,
              }}>
                اقتراحات
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {SUGGESTIONS.map((s, i) => (
                  <button
                    key={i}
                    className="paper-slip"
                    onClick={() => sendMessage(s)}
                    disabled={thinking}
                    style={{ fontSize: '0.8rem' }}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CSS animations */}
      <style>{`
        @keyframes dotBounce {
          0%, 60%, 100% { transform: translateY(0); }
          30% { transform: translateY(-6px); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 0.4; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.3); }
        }
        @keyframes spin {
          to { transform: translateY(-50%) rotate(360deg); }
        }
      `}</style>
    </section>
  );
}
