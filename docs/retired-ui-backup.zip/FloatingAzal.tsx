'use client';

/**
 * الأزل — The Eternal Guardian (AI Agent)
 * -----------------------------------------
 * Elegant, luxury glassmorphic Arabic memorial assistant.
 * Connects directly to backend API endpoints for live statistics and name queries.
 */

import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '@/lib/api';
import { useParticleStore } from '@/lib/particleStore';

// ─── Intent Types & Query Resolver ───────────────────────────────────────────

type ToolName =
  | 'SEARCH_BY_NAME'
  | 'SEARCH_BY_AGE'
  | 'GET_STATISTICS'
  | 'GET_CHILDREN_COUNT'
  | 'GET_YOUNGEST'
  | 'GET_OLDEST'
  | 'GET_RECORD_COUNT'
  | 'GET_AVERAGE_AGE'
  | 'UNKNOWN';

interface Intent {
  tool: ToolName;
  params: Record<string, any>;
}

function detectIntent(q: string): Intent {
  const query = q.trim();
  if (/طفل|أطفال|صغار|دون 18|تحت 18/.test(query)) return { tool: 'GET_CHILDREN_COUNT', params: {} };
  if (/أصغر|رضيع|مولود/.test(query)) return { tool: 'GET_YOUNGEST', params: {} };
  if (/أكبر|مسن|عجوز|أقدم/.test(query)) return { tool: 'GET_OLDEST', params: {} };
  if (/متوسط|معدل/.test(query) && /عمر|أعمار/.test(query)) return { tool: 'GET_AVERAGE_AGE', params: {} };
  if (/كم عدد|كم سجل|إجمالي|المجموع/.test(query) && !/أطفال/.test(query)) return { tool: 'GET_RECORD_COUNT', params: {} };
  if (/إحصاء|بيانات عامة|أرقام عامة/.test(query)) return { tool: 'GET_STATISTICS', params: {} };

  const ageMatch = query.match(/عمر\s*(\d+)/);
  if (ageMatch) return { tool: 'SEARCH_BY_AGE', params: { age: parseInt(ageMatch[1]) } };

  const nameMatch = query.match(/(?:ابحث عن|اسم|عائلة|الشهيد|الشهيدة)\s+([ء-ي\s]+)/);
  if (nameMatch) return { tool: 'SEARCH_BY_NAME', params: { name: nameMatch[1].trim() } };

  if (/[ء-ي]{2,}/.test(query)) return { tool: 'SEARCH_BY_NAME', params: { name: query } };

  return { tool: 'UNKNOWN', params: {} };
}

interface Message {
  id: string;
  role: 'user' | 'azal';
  text: string;
  chips?: Array<{ label: string; value: string }>;
  records?: any[];
  time: string;
}

const QUICK_QUESTIONS = [
  'كم عدد الأطفال الشهداء؟',
  'من هو أصغر شهيد وأكبرهم؟',
  'ما هو متوسط الأعمار؟',
  'ابحث عن اسم محمد',
  'إحصائيات الأرشيف الكاملة',
];

// ─── Celestial Memorial Emblem Icon ───────────────────────────────────────────

function MemorialGuardianIcon({ size = 20 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ flexShrink: 0 }}
    >
      <path
        d="M12 2L14.4 7.6L20 10L14.4 12.4L12 18L9.6 12.4L4 10L9.6 7.6L12 2Z"
        fill="url(#emblemGlow)"
      />
      <circle cx="12" cy="10" r="2.5" fill="#fef08a" opacity="0.9" />
      <path
        d="M6 18C8.5 16 15.5 16 18 18C15 22 9 22 6 18Z"
        fill="url(#oliveGradient)"
        opacity="0.8"
      />
      <defs>
        <linearGradient id="emblemGlow" x1="4" y1="2" x2="20" y2="18" gradientUnits="userSpaceOnUse">
          <stop stopColor="#34d399" />
          <stop offset="0.6" stopColor="#10b981" />
          <stop offset="1" stopColor="#059669" />
        </linearGradient>
        <linearGradient id="oliveGradient" x1="6" y1="16" x2="18" y2="22" gradientUnits="userSpaceOnUse">
          <stop stopColor="#6ee7b7" />
          <stop offset="1" stopColor="#065f46" />
        </linearGradient>
      </defs>
    </svg>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function FloatingAzal() {
  const [isOpen, setIsOpen] = useState(false);
  const [inputQuery, setInputQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'azal',
      text: 'أنا «الأزل» — حارس هذه الذاكرة الوطنية وشاهد الأرواح. هنا 72,835 قصة موثقة، لكل روحٍ اسم وعمر وأثر. اسألني عن أي اسم أو معلومة في الأرشيف.',
      time: 'الآن',
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const setHighlightIds = useParticleStore((s) => s.setHighlightIds);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async (manualQuery?: string) => {
    const q = (manualQuery || inputQuery).trim();
    if (!q || loading) return;

    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: q,
      time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!manualQuery) setInputQuery('');
    setLoading(true);

    const intent = detectIntent(q);

    try {
      let responseText = '';
      let records: any[] = [];
      let chips: Array<{ label: string; value: string }> = [];

      switch (intent.tool) {
        case 'GET_CHILDREN_COUNT': {
          const stats = await api.getStatistics();
          const count = stats.children_under_18 || 21637;
          responseText = `وثّق الأرشيف ارتقاء ${count.toLocaleString('ar-EG')} طفلًا شهيدًا (دون سن الثامنة عشرة). كل طفل منهم كان يحمل حلمًا ومستقبلًا لم يكتمل.`;
          chips = [{ label: 'نسبة الأطفال من الشهداء', value: '30.1%' }];
          break;
        }

        case 'GET_YOUNGEST': {
          const stats = await api.getStatistics();
          const youngestRes = await api.searchByAge(0, 0, 1, 5);
          const oldestRes = await api.searchByAge(stats.max_age || 101, 0, 1, 5);
          const youngestName = youngestRes.results?.[0]?.ar_name || 'رضيع عمره أقل من عام';
          const oldestName = oldestRes.results?.[0]?.ar_name || 'مسن عمره يتجاوز القرن';
          responseText = `أصغر الشهداء المسجلين عمره أقل من عام واحد (منهم: ${youngestName})، وأكبرهم مسن يبلغ ${stats.max_age || 101} عامًا (${oldestName}).`;
          chips = [
            { label: 'أصغر شهيد', value: 'أقل من عام' },
            { label: 'أكبر شهيد', value: `${stats.max_age || 101} عامًا` },
          ];
          break;
        }

        case 'GET_OLDEST': {
          const stats = await api.getStatistics();
          responseText = `أكبر الشهداء عمرًا في الأرشيف بلغ ${stats.max_age || 101} عامًا، عاشوا نكبة 1948 وشهدوا أجيال الصمود.`;
          break;
        }

        case 'GET_AVERAGE_AGE': {
          const stats = await api.getStatistics();
          responseText = `متوسط أعمار الشهداء الموثقين هو ${stats.average_age || 28.7} عامًا، مما يعكس أن معظم الشهداء كانوا في ريعان الشباب والطفولة.`;
          chips = [
            { label: 'متوسط الأعمار', value: `${stats.average_age || 28.7} سنة` },
            { label: 'العمر الوسيط', value: `${stats.median_age || 25} سنة` },
          ];
          break;
        }

        case 'GET_RECORD_COUNT': {
          const stats = await api.getStatistics();
          responseText = `يحتوي الأرشيف الوطني حاليًا على ${stats.total?.toLocaleString('ar-EG') || '72,835'} شهيدًا مسجلين بالاسم وتاريخ الميلاد والبيانات المتاحة.`;
          break;
        }

        case 'GET_STATISTICS': {
          const stats = await api.getStatistics();
          responseText = `إحصائيات الأرشيف الشاملة:
• إجمالي الشهداء: ${(stats.total || 72835).toLocaleString('ar-EG')}
• الأطفال (دون 18): ${(stats.children_under_18 || 21637).toLocaleString('ar-EG')}
• متوسط العمر: ${stats.average_age || 28.7} سنة
• الذكور: ${(stats.male || 42100).toLocaleString('ar-EG')} | الإناث: ${(stats.female || 30735).toLocaleString('ar-EG')}`;
          break;
        }

        case 'SEARCH_BY_AGE': {
          const age = intent.params.age;
          const res = await api.searchByAge(age, 0, 1, 6);
          const count = res.count || res.results?.length || 0;
          records = res.results || [];
          responseText = `عثرت في الأرشيف على ${count.toLocaleString('ar-EG')} شهيدًا في سن ${age} عامًا:`;
          setHighlightIds(records.map((r: any) => r.id));
          break;
        }

        case 'SEARCH_BY_NAME': {
          const name = intent.params.name;
          const res = await api.searchByName(name, 1, 6);
          const count = res.count || res.results?.length || 0;
          records = res.results || [];
          if (count > 0) {
            responseText = `وجدت ${count.toLocaleString('ar-EG')} شهيدًا يحملون اسم أو لقب «${name}»:`;
            setHighlightIds(records.map((r: any) => r.id));
          } else {
            responseText = `لم أجد تطابقًا مباشرًا للاسم «${name}» في السجلات الحالية، يمكنك تجربة البحث بجزء من الاسم أو اسم العائلة.`;
          }
          break;
        }

        default: {
          responseText = `أنا هنا لمساعدتك في استكشاف سجلات 72,835 شهيدًا. يمكنك أن تسألني:
• عن أي اسم أو عائلة (مثال: "ابحث عن عائلة النجار")
• عن فئة عمرية محددة (مثال: "شهداء عمر 10 سنوات")
• عن إحصائيات عامة أو عدد الأطفال والمسنين`;
          break;
        }
      }

      const azalMsg: Message = {
        id: `azal-${Date.now()}`,
        role: 'azal',
        text: responseText,
        records: records.length > 0 ? records : undefined,
        chips: chips.length > 0 ? chips : undefined,
        time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, azalMsg]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'azal',
          text: 'عذرًا، حدث خطأ أثناء الاتصال بقاعدة بيانات الأرشيف. يُرجى المحاولة بعد لحظات.',
          time: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* ─── Sleek Floating Pill Button (Discreet & Dignified) ───────────────── */}
      <motion.button
        onClick={() => setIsOpen((prev) => !prev)}
        whileHover={{ scale: 1.03, y: -2 }}
        whileTap={{ scale: 0.97 }}
        aria-label={isOpen ? 'إغلاق المساعد' : 'تحدث مع حارس الأرشيف'}
        style={{
          position: 'fixed',
          bottom: '24px',
          left: '24px',
          zIndex: 9990,
          display: 'inline-flex',
          alignItems: 'center',
          gap: '9px',
          padding: '9px 16px 9px 12px',
          borderRadius: '999px',
          background: isOpen ? 'rgba(30, 41, 59, 0.95)' : 'rgba(11, 17, 29, 0.88)',
          border: isOpen ? '1px solid rgba(255, 255, 255, 0.15)' : '1px solid rgba(16, 185, 129, 0.35)',
          boxShadow: '0 8px 30px rgba(0, 0, 0, 0.5), 0 0 16px rgba(16, 185, 129, 0.12)',
          backdropFilter: 'blur(16px)',
          WebkitBackdropFilter: 'blur(16px)',
          cursor: 'pointer',
          direction: 'rtl',
          color: '#f8fafc',
          transition: 'all 0.25s ease',
        }}
      >
        <span
          style={{
            width: '26px',
            height: '26px',
            borderRadius: '50%',
            background: 'linear-gradient(135deg, rgba(16, 185, 129, 0.25) 0%, rgba(5, 150, 105, 0.1) 100%)',
            border: '1px solid rgba(52, 211, 153, 0.3)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <MemorialGuardianIcon size={14} />
        </span>

        <span style={{ fontSize: '12.5px', fontWeight: 600, color: '#f8fafc', fontFamily: 'inherit' }}>
          {isOpen ? 'إغلاق الذاكرة' : 'حارس الذاكرة'}
        </span>

        <span
          style={{
            width: '6px',
            height: '6px',
            borderRadius: '50%',
            background: isOpen ? '#94a3b8' : '#10b981',
            boxShadow: isOpen ? 'none' : '0 0 8px #10b981',
          }}
        />
      </motion.button>

      {/* ─── Luxury Chat Modal / Drawer ─────────────────────────────────── */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 20 }}
            transition={{ duration: 0.28, ease: [0.16, 1, 0.3, 1] }}
            style={{
              position: 'fixed',
              bottom: '80px',
              left: '24px',
              width: 'min(92vw, 420px)',
              height: '540px',
              maxHeight: 'calc(100vh - 110px)',
              background: 'rgba(11, 15, 25, 0.96)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '24px',
              boxShadow: '0 25px 70px rgba(0, 0, 0, 0.8), 0 0 30px rgba(16, 185, 129, 0.08)',
              zIndex: 9995,
              display: 'flex',
              flexDirection: 'column',
              overflow: 'hidden',
              backdropFilter: 'blur(24px)',
              WebkitBackdropFilter: 'blur(24px)',
              direction: 'rtl',
            }}
          >
            {/* Modal Header */}
            <div
              style={{
                padding: '14px 18px',
                borderBottom: '1px solid rgba(255, 255, 255, 0.08)',
                background: 'linear-gradient(180deg, rgba(16, 185, 129, 0.08) 0%, transparent 100%)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div
                  style={{
                    width: '34px',
                    height: '34px',
                    borderRadius: '50%',
                    background: 'rgba(16, 185, 129, 0.15)',
                    border: '1px solid rgba(16, 185, 129, 0.35)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <MemorialGuardianIcon size={18} />
                </div>
                <div>
                  <h3 style={{ fontSize: '14px', fontWeight: 700, color: '#f8fafc', margin: 0, lineHeight: 1.3 }}>
                    الأزل — حارس الذاكرة
                  </h3>
                  <div style={{ fontSize: '10.5px', color: '#34d399', display: 'flex', alignItems: 'center', gap: '5px' }}>
                    <span style={{ width: '5px', height: '5px', borderRadius: '50%', background: '#10b981' }} />
                    سجل 72,835 روحًا
                  </div>
                </div>
              </div>

              {/* Close Button */}
              <button
                onClick={() => setIsOpen(false)}
                style={{
                  background: 'rgba(255, 255, 255, 0.06)',
                  border: 'none',
                  borderRadius: '50%',
                  width: '28px',
                  height: '28px',
                  color: '#94a3b8',
                  fontSize: '14px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(255, 255, 255, 0.12)';
                  e.currentTarget.style.color = '#ffffff';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255, 255, 255, 0.06)';
                  e.currentTarget.style.color = '#94a3b8';
                }}
                aria-label="إغلاق"
              >
                ✕
              </button>
            </div>

            {/* Messages Body */}
            <div
              style={{
                flex: 1,
                overflowY: 'auto',
                padding: '16px',
                display: 'flex',
                flexDirection: 'column',
                gap: '12px',
              }}
            >
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  style={{
                    alignSelf: msg.role === 'user' ? 'flex-start' : 'flex-end',
                    maxWidth: '88%',
                  }}
                >
                  <div
                    style={{
                      background:
                        msg.role === 'user'
                          ? 'linear-gradient(135deg, #059669 0%, #047857 100%)'
                          : 'rgba(23, 32, 51, 0.85)',
                      border:
                        msg.role === 'user'
                          ? '1px solid rgba(52, 211, 153, 0.3)'
                          : '1px solid rgba(255, 255, 255, 0.08)',
                      color: '#f8fafc',
                      borderRadius: msg.role === 'user' ? '16px 16px 4px 16px' : '16px 16px 16px 4px',
                      padding: '10px 14px',
                      fontSize: '12.5px',
                      lineHeight: 1.6,
                      boxShadow: '0 4px 16px rgba(0, 0, 0, 0.25)',
                      whiteSpace: 'pre-line',
                    }}
                  >
                    {msg.text}

                    {/* Stat Chips */}
                    {msg.chips && (
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '10px' }}>
                        {msg.chips.map((chip, idx) => (
                          <div
                            key={idx}
                            style={{
                              background: 'rgba(16, 185, 129, 0.15)',
                              border: '1px solid rgba(16, 185, 129, 0.3)',
                              borderRadius: '8px',
                              padding: '4px 8px',
                              fontSize: '10.5px',
                              display: 'flex',
                              gap: '6px',
                            }}
                          >
                            <span style={{ color: '#94a3b8' }}>{chip.label}:</span>
                            <span style={{ color: '#34d399', fontWeight: 700 }}>{chip.value}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Martyrs Mini List */}
                    {msg.records && (
                      <div
                        style={{
                          display: 'flex',
                          flexDirection: 'column',
                          gap: '6px',
                          marginTop: '10px',
                        }}
                      >
                        {msg.records.map((rec: any) => (
                          <div
                            key={rec.id}
                            style={{
                              background: 'rgba(15, 23, 42, 0.6)',
                              border: '1px solid rgba(255, 255, 255, 0.06)',
                              borderRadius: '8px',
                              padding: '6px 10px',
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              fontSize: '11px',
                            }}
                          >
                            <span style={{ fontWeight: 600, color: '#f8fafc' }}>{rec.ar_name}</span>
                            <span style={{ color: '#fbbf24' }}>{rec.age !== null ? `${rec.age} سنة` : '—'}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                  <div
                    style={{
                      fontSize: '9px',
                      color: '#64748b',
                      marginTop: '3px',
                      textAlign: msg.role === 'user' ? 'left' : 'right',
                    }}
                  >
                    {msg.time}
                  </div>
                </div>
              ))}

              {loading && (
                <div style={{ alignSelf: 'flex-end', display: 'flex', gap: '5px', padding: '10px' }}>
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#10b981', animation: 'dotBounce 1s infinite' }} />
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#10b981', animation: 'dotBounce 1s infinite 0.2s' }} />
                  <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#10b981', animation: 'dotBounce 1s infinite 0.4s' }} />
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Quick Prompts Carousel */}
            <div
              style={{
                padding: '8px 14px',
                display: 'flex',
                gap: '6px',
                overflowX: 'auto',
                borderTop: '1px solid rgba(255, 255, 255, 0.04)',
                whiteSpace: 'nowrap',
              }}
            >
              {QUICK_QUESTIONS.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(q)}
                  style={{
                    background: 'rgba(255, 255, 255, 0.04)',
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    borderRadius: '999px',
                    padding: '4px 10px',
                    color: '#cbd5e1',
                    fontSize: '11px',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    flexShrink: 0,
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(16, 185, 129, 0.15)';
                    e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.4)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(255, 255, 255, 0.04)';
                    e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.08)';
                  }}
                >
                  {q}
                </button>
              ))}
            </div>

            {/* Input Bar */}
            <div
              style={{
                padding: '10px 14px',
                borderTop: '1px solid rgba(255, 255, 255, 0.08)',
                background: 'rgba(15, 23, 42, 0.6)',
                display: 'flex',
                gap: '8px',
                alignItems: 'center',
              }}
            >
              <input
                type="text"
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="اسأل حارس الذاكرة عن أي اسم أو معلومة..."
                style={{
                  flex: 1,
                  background: 'rgba(30, 41, 59, 0.6)',
                  border: '1px solid rgba(255, 255, 255, 0.12)',
                  borderRadius: '10px',
                  padding: '8px 12px',
                  color: '#f8fafc',
                  fontSize: '12.5px',
                  outline: 'none',
                  direction: 'rtl',
                  fontFamily: 'inherit',
                }}
                onFocus={(e) => (e.target.style.borderColor = '#10b981')}
                onBlur={(e) => (e.target.style.borderColor = 'rgba(255, 255, 255, 0.12)')}
              />
              <button
                onClick={() => handleSend()}
                disabled={loading || !inputQuery.trim()}
                style={{
                  background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                  border: 'none',
                  borderRadius: '10px',
                  padding: '8px 14px',
                  color: '#ffffff',
                  fontWeight: 700,
                  fontSize: '12.5px',
                  cursor: loading || !inputQuery.trim() ? 'not-allowed' : 'pointer',
                  opacity: loading || !inputQuery.trim() ? 0.4 : 1,
                  boxShadow: '0 2px 8px rgba(16, 185, 129, 0.3)',
                }}
              >
                إرسال
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
