'use client';

import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

interface Particle {
  x: number;
  y: number;
  tx: number; // target x (number formation)
  ty: number; // target y
  sx: number; // scatter x
  sy: number; // scatter y
  vx: number;
  vy: number;
  r: number;  // radius
  alpha: number;
  color: string;
}

const PARTICLE_COUNT = typeof window !== 'undefined' && window.innerWidth < 768 ? 1500 : 4000;
const TEXT = '72,835';

function getTextPixels(text: string, width: number, height: number): Array<{ x: number; y: number }> {
  const offscreen = document.createElement('canvas');
  offscreen.width = width;
  offscreen.height = height;
  const ctx = offscreen.getContext('2d')!;

  const fontSize = Math.min(width * 0.22, height * 0.55);
  ctx.font = `700 ${fontSize}px "IBM Plex Sans Arabic", Arial`;
  ctx.fillStyle = '#000';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, width / 2, height / 2);

  const imageData = ctx.getImageData(0, 0, width, height);
  const pixels: Array<{ x: number; y: number }> = [];
  const step = 4; // sample every N pixels for performance

  for (let y = 0; y < height; y += step) {
    for (let x = 0; x < width; x += step) {
      const idx = (y * width + x) * 4;
      if (imageData.data[idx + 3] > 128) {
        pixels.push({ x, y });
      }
    }
  }
  return pixels;
}

export default function ParticleScene() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const rafRef = useRef<number>(0);
  const progressRef = useRef(0); // 0 = number form, 1 = scattered

  useEffect(() => {
    const canvas = canvasRef.current!;
    const section = sectionRef.current!;
    const ctx = canvas.getContext('2d')!;

    const resize = () => {
      canvas.width = section.clientWidth;
      canvas.height = section.clientHeight;
      initParticles();
    };

    function initParticles() {
      const W = canvas.width;
      const H = canvas.height;

      // Sample pixel positions from number text
      const pixels = getTextPixels(TEXT, W, H);

      const particles: Particle[] = [];
      for (let i = 0; i < PARTICLE_COUNT; i++) {
        // Target: random pixel from the text
        const pixel = pixels[Math.floor(Math.random() * pixels.length)] || { x: W / 2, y: H / 2 };

        // Scatter: random position across canvas
        const sx = Math.random() * W;
        const sy = Math.random() * H;

        particles.push({
          x: pixel.x + (Math.random() - 0.5) * 4,
          y: pixel.y + (Math.random() - 0.5) * 4,
          tx: pixel.x,
          ty: pixel.y,
          sx,
          sy,
          vx: 0,
          vy: 0,
          r: Math.random() * 1.5 + 0.5,
          alpha: 0.7 + Math.random() * 0.3,
          color: Math.random() < 0.05
            ? '#006233'
            : Math.random() < 0.03
            ? '#CE1126'
            : '#1A1714',
        });
      }
      particlesRef.current = particles;
    }

    function lerp(a: number, b: number, t: number) {
      return a + (b - a) * t;
    }

    function render() {
      const W = canvas.width;
      const H = canvas.height;
      const p = progressRef.current; // 0→1

      ctx.clearRect(0, 0, W, H);

      for (const pt of particlesRef.current) {
        // Interpolate between number formation and scatter
        const x = lerp(pt.tx, pt.sx, p);
        const y = lerp(pt.ty, pt.sy, p);
        const alpha = pt.alpha * (1 - p * 0.3);

        ctx.beginPath();
        ctx.arc(x, y, pt.r, 0, Math.PI * 2);
        ctx.fillStyle = pt.color;
        ctx.globalAlpha = alpha;
        ctx.fill();
      }
      ctx.globalAlpha = 1;

      rafRef.current = requestAnimationFrame(render);
    }

    resize();
    window.addEventListener('resize', resize);
    render();

    // ScrollTrigger controls progress 0→1
    const st = ScrollTrigger.create({
      trigger: section,
      start: 'top top',
      end: 'bottom top',
      scrub: 1.5,
      onUpdate: (self) => {
        progressRef.current = self.progress;
      },
    });

    // Text overlays with GSAP
    const phrase1 = section.querySelector('[data-phrase="1"]');
    const phrase2 = section.querySelector('[data-phrase="2"]');
    if (phrase1 && phrase2) {
      gsap.from(phrase1, {
        opacity: 0, y: 20,
        scrollTrigger: { trigger: section, start: '30% top', end: '55% top', scrub: true },
      });
      gsap.to(phrase1, {
        opacity: 0, y: -20,
        scrollTrigger: { trigger: section, start: '55% top', end: '70% top', scrub: true },
      });
      gsap.from(phrase2, {
        opacity: 0, y: 20,
        scrollTrigger: { trigger: section, start: '65% top', end: '85% top', scrub: true },
      });
    }

    return () => {
      cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', resize);
      st.kill();
    };
  }, []);

  return (
    <div
      ref={sectionRef}
      style={{
        position: 'relative',
        width: '100%',
        height: '300vh', // tall enough for pinned scroll scene
        background: 'var(--bg-base)',
      }}
    >
      {/* Sticky canvas container */}
      <div
        style={{
          position: 'sticky',
          top: 0,
          width: '100%',
          height: '100vh',
          overflow: 'hidden',
        }}
      >
        <canvas
          ref={canvasRef}
          className="canvas-scene"
          style={{ display: 'block' }}
          aria-hidden="true"
        />

        {/* Text phrases that appear during scroll */}
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'flex-end',
            paddingBottom: '15vh',
            pointerEvents: 'none',
          }}
        >
          <p
            data-phrase="1"
            style={{
              fontFamily: 'var(--font-arabic)',
              fontSize: 'clamp(1rem, 2.5vw, 1.5rem)',
              color: 'var(--text-secondary)',
              direction: 'rtl',
              opacity: 0,
              position: 'absolute',
              bottom: '22vh',
            }}
          >
            كل نقطة تمثّل سجلًا.
          </p>
          <p
            data-phrase="2"
            style={{
              fontFamily: 'var(--font-arabic)',
              fontSize: 'clamp(1rem, 2.5vw, 1.5rem)',
              color: 'var(--text-secondary)',
              direction: 'rtl',
              opacity: 0,
              position: 'absolute',
              bottom: '15vh',
            }}
          >
            لكن خلف كل سجل اسم.
          </p>
        </div>
      </div>
    </div>
  );
}
