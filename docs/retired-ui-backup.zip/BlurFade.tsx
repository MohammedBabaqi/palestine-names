'use client';

/**
 * BlurFade (Magic UI pattern — implemented locally)
 * Fades and blurs an element into view when it enters the viewport.
 * Uses framer-motion AnimatePresence + motion.div.
 */

import { useRef } from 'react';
import { AnimatePresence, motion, useInView, type Variant } from 'framer-motion';

interface BlurFadeProps {
  children: React.ReactNode;
  className?: string;
  variant?: {
    hidden: Variant;
    visible: Variant;
  };
  duration?: number;
  delay?: number;
  yOffset?: number;
  inView?: boolean;
  inViewMargin?: string;
  blur?: string;
}

const DEFAULT_ANIMATION_VARIANTS = {
  hidden: { y: 6, opacity: 0, filter: 'blur(6px)' },
  visible: { y: 0, opacity: 1, filter: 'blur(0px)' },
};

export default function BlurFade({
  children,
  className,
  variant,
  duration = 0.4,
  delay = 0,
  yOffset = 6,
  inView = false,
  inViewMargin = '-50px',
  blur = '6px',
}: BlurFadeProps) {
  const ref = useRef(null);
  const inViewResult = useInView(ref, { once: true, margin: inViewMargin as any });
  const isVisible = !inView ? true : inViewResult;
  const animationVariants = variant ?? {
    hidden: { y: yOffset, opacity: 0, filter: `blur(${blur})` },
    visible: { y: 0, opacity: 1, filter: 'blur(0px)' },
  };

  return (
    <AnimatePresence>
      <motion.div
        ref={ref}
        initial="hidden"
        animate={isVisible ? 'visible' : 'hidden'}
        exit="hidden"
        variants={animationVariants}
        transition={{
          delay: 0.04 + delay,
          duration,
          ease: [0.21, 0.47, 0.32, 0.98],
        }}
        className={className}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
