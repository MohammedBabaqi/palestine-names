'use client';

/**
 * AlgorithmsSection
 * -----------------
 * Educational and algorithmic exhibit.
 * Demonstrates how computer science, indexing, and data structures preserve national memory.
 */

import { motion } from 'framer-motion';

const ALGORITHMS = [
  {
    category: 'خوارزميات البحث (Search)',
    items: [
      { name: 'Linear Search', arabic: 'البحث الخطي', complexity: 'O(n)', use: 'البحث بالاسم واللقب', desc: 'يمسح 72,835 اسمًا بدقة تامة للعثور على أي تطابق جزئي.' },
      { name: 'Binary Search', arabic: 'البحث الثنائي', complexity: 'O(log n)', use: 'البحث بالأعمار وتواريخ الميلاد', desc: 'يقسم فضاء البحث إلى نصفين في كل خطوة، محققًا النتيجة في أقل من 17 عملية مقارنة.' },
      { name: 'Range Scan', arabic: 'المسح بالنطاق', complexity: 'O(k + log n)', use: 'فئات الأطفال والمسنين', desc: 'يستخرج الفئات العمرية المستهدفة عبر مؤشرات زمنية مرتبة مسبقًا.' },
    ],
  },
  {
    category: 'خوارزميات الترتيب (Sorting)',
    items: [
      { name: 'Merge Sort', arabic: 'الترتيب بالدمج', complexity: 'O(n log n)', use: 'فرز الأسماء العربية أبجديًا', desc: 'خوارزمية مستقرة تضمن المحافظة على الترتيب الأصلي للألقاب المتطابقة.' },
      { name: 'Quick Sort', arabic: 'الترتيب السريع', complexity: 'O(n log n)', use: 'فرز الأرواح حسب العمر الزمني', desc: 'ترتيب فائق الكفاءة يقسّم البيانات حول محور مركزي في الذاكرة.' },
    ],
  },
];

export default function AlgorithmsSection() {
  return (
    <section
      id="algorithms"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '80vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
        padding: '100px 24px',
        direction: 'rtl',
      }}
    >
      <div style={{ maxWidth: '1050px', width: '100%' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '48px' }}>
          <span
            style={{
              fontSize: '11px',
              fontFamily: "'JetBrains Mono', monospace",
              color: '#10b981',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
            }}
          >
            DATA ARCHITECTURE — هندسة الذاكرة
          </span>
          <h2
            style={{
              fontSize: 'clamp(1.8rem, 4vw, 2.8rem)',
              fontWeight: 800,
              color: '#f8fafc',
              marginTop: '10px',
            }}
          >
            الخوارزميات التي تصون الذاكرة
          </h2>
          <p style={{ fontSize: '15px', color: '#94a3b8', marginTop: '8px', maxWidth: '650px', margin: '8px auto 0' }}>
            البيانات ليست مجرد أرقام جافة؛ الخوارزميات هنا تعمل كحارس أمين يتيح استرجاع أي قصة من بين 72,835 سجلًا في أجزاء من الألف من الثانية.
          </p>
        </div>

        {/* Groups */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }}>
          {ALGORITHMS.map((grp, gi) => (
            <div
              key={gi}
              style={{
                background: 'rgba(15, 23, 42, 0.75)',
                border: '1px solid rgba(255, 255, 255, 0.08)',
                borderRadius: '24px',
                padding: '28px',
                backdropFilter: 'blur(16px)',
              }}
            >
              <h3 style={{ fontSize: '17px', fontWeight: 700, color: '#34d399', marginBottom: '20px' }}>
                {grp.category}
              </h3>

              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
                  gap: '16px',
                }}
              >
                {grp.items.map((item, ii) => (
                  <motion.div
                    key={ii}
                    whileHover={{ y: -3 }}
                    style={{
                      background: 'rgba(30, 41, 59, 0.5)',
                      border: '1px solid rgba(255, 255, 255, 0.06)',
                      borderRadius: '16px',
                      padding: '18px',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                      <span style={{ fontSize: '15px', fontWeight: 700, color: '#f8fafc' }}>
                        {item.arabic}
                      </span>
                      <span
                        style={{
                          background: 'rgba(16, 185, 129, 0.15)',
                          color: '#34d399',
                          border: '1px solid rgba(16, 185, 129, 0.3)',
                          fontSize: '11px',
                          fontFamily: "'JetBrains Mono', monospace",
                          padding: '2px 8px',
                          borderRadius: '6px',
                          fontWeight: 600,
                        }}
                      >
                        {item.complexity}
                      </span>
                    </div>

                    <div style={{ fontSize: '11px', color: '#fbbf24', marginBottom: '6px' }}>
                      الاستخدام: {item.use}
                    </div>

                    <p style={{ fontSize: '12px', color: '#94a3b8', lineHeight: 1.6, margin: 0 }}>
                      {item.desc}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
