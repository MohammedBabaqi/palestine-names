'use client';

/**
 * OneNameScene
 * ------------
 * An intimate, reverent spotlight on a single human soul from the 72,835 records.
 * Shifts the user's perception from the vast crowd of thousands to the unique individual.
 * Includes interactive button to cycle through other martyrs.
 */

import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '@/lib/api';
import type { Record } from '@/lib/types';

export default function OneNameScene() {
  const [person, setPerson] = useState<Record | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchRandom = useCallback(() => {
    setLoading(true);
    api.getOneRandom()
      .then((res) => {
        setPerson(res);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    fetchRandom();
  }, [fetchRandom]);

  const isChild = person?.age !== null && person?.age !== undefined && person.age < 18;
  const sexLabel = person?.sex === 'm' ? 'ذكر' : person?.sex === 'f' ? 'أنثى' : null;

  return (
    <section
      id="one-name"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
        padding: '80px 24px',
        direction: 'rtl',
      }}
    >
      <div
        style={{
          maxWidth: '750px',
          width: '100%',
          background: 'rgba(10, 15, 26, 0.88)',
          border: isChild ? '1px solid rgba(245, 158, 11, 0.4)' : '1px solid rgba(16, 185, 129, 0.35)',
          borderRadius: '28px',
          padding: '48px 36px',
          backdropFilter: 'blur(20px)',
          boxShadow: isChild
            ? '0 25px 60px rgba(0,0,0,0.8), 0 0 35px rgba(245, 158, 11, 0.15)'
            : '0 25px 60px rgba(0,0,0,0.8), 0 0 35px rgba(16, 185, 129, 0.15)',
          textAlign: 'center',
          position: 'relative',
        }}
      >
        <span
          style={{
            fontSize: '11px',
            fontFamily: "'JetBrains Mono', monospace",
            color: isChild ? '#fbbf24' : '#34d399',
            letterSpacing: '0.2em',
            textTransform: 'uppercase',
          }}
        >
          {isChild ? '✦ روح طفل شهيد ✦' : '✦ روح من بين الآلاف ✦'}
        </span>

        <AnimatePresence mode="wait">
          {person && (
            <motion.div
              key={person.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.5 }}
            >
              {/* Name */}
              <h2
                style={{
                  fontSize: 'clamp(2rem, 5.5vw, 3.8rem)',
                  fontWeight: 800,
                  color: '#f8fafc',
                  marginTop: '16px',
                  marginBottom: '20px',
                  lineHeight: 1.2,
                  letterSpacing: '-0.02em',
                }}
              >
                {person.ar_name || person.en_name}
              </h2>

              {/* Data Grid */}
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'center',
                  gap: '24px',
                  flexWrap: 'wrap',
                  margin: '32px 0',
                }}
              >
                {person.age !== null && person.age !== undefined && (
                  <div
                    style={{
                      background: 'rgba(255, 255, 255, 0.04)',
                      border: '1px solid rgba(255, 255, 255, 0.08)',
                      borderRadius: '16px',
                      padding: '12px 24px',
                      minWidth: '110px',
                    }}
                  >
                    <div style={{ fontSize: '11px', color: '#94a3b8' }}>العمر</div>
                    <div
                      style={{
                        fontSize: '24px',
                        fontWeight: 700,
                        color: isChild ? '#fbbf24' : '#6ee7b7',
                        marginTop: '4px',
                      }}
                    >
                      {person.age} عامًا
                    </div>
                  </div>
                )}

                {sexLabel && (
                  <div
                    style={{
                      background: 'rgba(255, 255, 255, 0.04)',
                      border: '1px solid rgba(255, 255, 255, 0.08)',
                      borderRadius: '16px',
                      padding: '12px 24px',
                      minWidth: '110px',
                    }}
                  >
                    <div style={{ fontSize: '11px', color: '#94a3b8' }}>الجنس</div>
                    <div style={{ fontSize: '24px', fontWeight: 700, color: '#f8fafc', marginTop: '4px' }}>
                      {sexLabel}
                    </div>
                  </div>
                )}

                {person.id && (
                  <div
                    style={{
                      background: 'rgba(255, 255, 255, 0.04)',
                      border: '1px solid rgba(255, 255, 255, 0.08)',
                      borderRadius: '16px',
                      padding: '12px 24px',
                      minWidth: '110px',
                    }}
                  >
                    <div style={{ fontSize: '11px', color: '#94a3b8' }}>رقم السجل</div>
                    <div
                      style={{
                        fontSize: '18px',
                        fontFamily: "'JetBrains Mono', monospace",
                        color: '#cbd5e1',
                        marginTop: '6px',
                      }}
                    >
                      #{person.id}
                    </div>
                  </div>
                )}
              </div>

              <p style={{ fontSize: '13px', color: '#64748b', fontStyle: 'italic', marginBottom: '28px' }}>
                واحد من بين 72,835 شهيدًا مسجلين رسميًا في هذا الأرشيف.
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Action Button to cycle souls */}
        <button
          onClick={fetchRandom}
          disabled={loading}
          className="btn-emerald"
          style={{
            cursor: loading ? 'wait' : 'pointer',
            opacity: loading ? 0.7 : 1,
            gap: '8px',
          }}
        >
          <span>استحضر روحًا أخرى</span>
          <span style={{ fontSize: '16px' }}>↺</span>
        </button>
      </div>
    </section>
  );
}
