'use client';

/**
 * NamesField
 * ----------
 * Floating constellation of Arabic names drifting softly across the night sky.
 * Pure React + RAF animation (zero GSAP errors).
 */

import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';

interface FloatingName {
  id: string;
  name: string;
  x: number;
  y: number;
  size: number;
  opacity: number;
  speed: number;
  color: string;
}

const FALLBACK_NAMES = [
  'محمد', 'أحمد', 'عبدالله', 'خالد', 'يوسف', 'إبراهيم', 'علي', 'عمر',
  'فاطمة', 'مريم', 'زينب', 'آمنة', 'خديجة', 'سارة', 'هالة', 'نور',
  'رائد', 'سامي', 'طارق', 'جمال', 'ليلى', 'رنا', 'دينا', 'منى',
  'حسن', 'حسين', 'محمود', 'كريم', 'وليد', 'أيمن', 'عائشة', 'سلمى',
  'ياسر', 'أسامة', 'رشيد', 'عماد', 'حنين', 'ريم', 'لمى', 'شيماء',
  'بيلسان', 'شام', 'جنى', 'إياس', 'حمزة', 'بلال', 'سليمان', 'يحيى',
];

const COLORS = ['#f8fafc', '#cbd5e1', '#6ee7b7', '#fde047', '#fca5a5'];

export default function NamesField() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [names, setNames] = useState<FloatingName[]>([]);
  const [hoveredName, setHoveredName] = useState<string | null>(null);

  useEffect(() => {
    api.getSample(60)
      .then((res) => {
        const real = (res.records || [])
          .map((r: { ar_name?: string }) => r.ar_name || '')
          .filter(Boolean);
        buildNames(real.length >= 20 ? real : FALLBACK_NAMES);
      })
      .catch(() => buildNames(FALLBACK_NAMES));

    function buildNames(list: string[]) {
      const built: FloatingName[] = list.slice(0, 50).map((n, i) => ({
        id: `name-${i}`,
        name: n,
        x: (i * 17) % 90 + 5,
        y: ((i * 23) % 85) + 8,
        size: 14 + (i % 6) * 4,
        opacity: 0.25 + ((i % 5) * 0.15),
        speed: 0.3 + ((i % 4) * 0.2),
        color: COLORS[i % COLORS.length],
      }));
      setNames(built);
    }
  }, []);

  return (
    <section
      id="names"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
        padding: '80px 24px',
        overflow: 'hidden',
      }}
    >
      {/* Background Vignette Overlay */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'radial-gradient(circle at center, transparent 30%, rgba(6,8,13,0.8) 100%)',
          pointerEvents: 'none',
        }}
      />

      {/* Floating Arabic Names Constellation */}
      <div
        ref={containerRef}
        style={{
          position: 'absolute',
          inset: 0,
          pointerEvents: 'none',
        }}
      >
        {names.map((n) => (
          <motion.span
            key={n.id}
            onMouseEnter={() => setHoveredName(n.name)}
            onMouseLeave={() => setHoveredName(null)}
            animate={{
              y: [0, -12, 0],
              x: [0, 8, 0],
            }}
            transition={{
              duration: 4 + n.speed * 3,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            style={{
              position: 'absolute',
              left: `${n.x}%`,
              top: `${n.y}%`,
              fontFamily: "'IBM Plex Sans Arabic', sans-serif",
              fontSize: `${n.size}px`,
              fontWeight: n.size > 22 ? 700 : 500,
              color: hoveredName === n.name ? '#34d399' : n.color,
              opacity: hoveredName === n.name ? 1 : n.opacity,
              direction: 'rtl',
              cursor: 'pointer',
              pointerEvents: 'auto',
              userSelect: 'none',
              filter: hoveredName === n.name ? 'drop-shadow(0 0 12px #10b981)' : 'none',
              transform: hoveredName === n.name ? 'scale(1.2)' : 'scale(1)',
              transition: 'color 0.25s, opacity 0.25s, transform 0.25s',
              whiteSpace: 'nowrap',
            }}
          >
            {n.name}
          </motion.span>
        ))}
      </div>

      {/* Centerpiece Poetic Title */}
      <div
        style={{
          position: 'relative',
          zIndex: 20,
          textAlign: 'center',
          direction: 'rtl',
          background: 'rgba(10, 15, 26, 0.85)',
          border: '1px solid rgba(255, 255, 255, 0.1)',
          borderRadius: '24px',
          padding: '36px 40px',
          maxWidth: '650px',
          backdropFilter: 'blur(20px)',
          boxShadow: '0 20px 50px rgba(0,0,0,0.6)',
        }}
      >
        <span
          style={{
            fontSize: '11px',
            fontFamily: "'JetBrains Mono', monospace",
            color: '#10b981',
            letterSpacing: '0.2em',
            textTransform: 'uppercase',
          }}
        >
          NAMES IN THE SKY — سماء الأسماء
        </span>

        <h2
          style={{
            fontSize: 'clamp(1.6rem, 4vw, 2.5rem)',
            fontWeight: 700,
            color: '#f8fafc',
            marginTop: '12px',
            lineHeight: 1.3,
          }}
        >
          {hoveredName ? `«${hoveredName}»` : 'لكل روحٍ اسم... ولكل اسمٍ وطن'}
        </h2>

        <p
          style={{
            fontSize: '14px',
            color: '#94a3b8',
            marginTop: '12px',
            lineHeight: 1.7,
          }}
        >
          تتسامى أسماء الشهداء ككواكب مضيئة في سماء فلسطين. مرّر الفأرة فوق أي اسم لاستحضاره، أو استكشف الأرواح في الأرشيف أدناه.
        </p>
      </div>
    </section>
  );
}
