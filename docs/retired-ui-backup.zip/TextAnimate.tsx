'use client';

/**
 * TextAnimate (Magic UI pattern — implemented locally)
 * Animates text character-by-character or word-by-word.
 * Variants: blur-in, slide-up, fade-in.
 */

import { motion, useInView, type Variant } from 'framer-motion';
import { useRef } from 'react';

type AnimationType = 'blur-in' | 'slide-up' | 'fade-in' | 'slide-left';

interface TextAnimateProps {
  children: string;
  className?: string;
  type?: AnimationType;
  delay?: number;
  duration?: number;
  by?: 'character' | 'word' | 'line';
  startOnView?: boolean;
  once?: boolean;
}

const VARIANTS: Record<AnimationType, { container: any; item: { hidden: Variant; visible: Variant } }> = {
  'blur-in': {
    container: { hidden: {}, visible: { transition: { staggerChildren: 0.05 } } },
    item: {
      hidden: { opacity: 0, filter: 'blur(8px)', y: 4 },
      visible: { opacity: 1, filter: 'blur(0px)', y: 0 },
    },
  },
  'slide-up': {
    container: { hidden: {}, visible: { transition: { staggerChildren: 0.04 } } },
    item: {
      hidden: { opacity: 0, y: 20 },
      visible: { opacity: 1, y: 0 },
    },
  },
  'fade-in': {
    container: { hidden: {}, visible: { transition: { staggerChildren: 0.06 } } },
    item: {
      hidden: { opacity: 0 },
      visible: { opacity: 1 },
    },
  },
  'slide-left': {
    container: { hidden: {}, visible: { transition: { staggerChildren: 0.05 } } },
    item: {
      hidden: { opacity: 0, x: -20 },
      visible: { opacity: 1, x: 0 },
    },
  },
};

export default function TextAnimate({
  children,
  className,
  type = 'blur-in',
  delay = 0,
  duration = 0.4,
  by = 'character',
  startOnView = true,
  once = true,
}: TextAnimateProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once, margin: '-20px' });
  const { container, item } = VARIANTS[type];

  const segments = by === 'character'
    ? children.split('')
    : by === 'word'
    ? children.split(' ')
    : [children];

  return (
    <motion.span
      ref={ref}
      className={className}
      initial="hidden"
      animate={!startOnView || isInView ? 'visible' : 'hidden'}
      variants={container}
      style={{ display: 'inline-block' }}
    >
      {segments.map((seg, i) => (
        <motion.span
          key={i}
          variants={item}
          transition={{ duration, delay: delay + i * (by === 'character' ? 0.03 : 0.06) }}
          style={{ display: 'inline-block', whiteSpace: 'pre' }}
        >
          {seg}
          {by === 'word' && i < segments.length - 1 ? ' ' : ''}
        </motion.span>
      ))}
    </motion.span>
  );
}
