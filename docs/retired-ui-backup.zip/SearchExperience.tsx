'use client';

import { useState, useCallback } from 'react';
import api from '@/lib/api';

type SearchMode = 'name' | 'age' | 'date';

interface SearchResult {
  algorithm: string;
  complexity: string;
  comparisons?: number;
  steps?: number;
  count: number;
  results: any[];
  pagination?: any;
}

export default function SearchExperience() {
  const [mode, setMode] = useState<SearchMode>('name');
  const [query, setQuery] = useState('');
  const [ageVal, setAgeVal] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [result, setResult] = useState<SearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = useCallback(async () => {
    setLoading(true);
    setSearched(true);
    try {
      let res: any;
      if (mode === 'name') {
        res = await api.searchByName(query);
      } else if (mode === 'age') {
        res = await api.searchByAge(parseInt(ageVal) || 0, 2);
      } else {
        res = await api.searchByDate(dateFrom || undefined, dateTo || undefined);
      }
      setResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [mode, query, ageVal, dateFrom, dateTo]);

  return (
    <div style={{ direction: 'rtl' }}>
      {/* Search mode tabs */}
      <div className="tab-list" style={{ marginBottom: 24 }}>
        {(['name', 'age', 'date'] as SearchMode[]).map((m) => (
          <button
            key={m}
            className={`tab-btn ${mode === m ? 'active' : ''}`}
            onClick={() => { setMode(m); setResult(null); setSearched(false); }}
            id={`search-tab-${m}`}
          >
            {m === 'name' ? 'بالاسم' : m === 'age' ? 'بالعمر' : 'بالتاريخ'}
          </button>
        ))}
      </div>

      {/* Input area */}
      <div style={{ marginBottom: 24 }}>
        {mode === 'name' && (
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <input
              type="text"
              placeholder="اكتب الاسم بالعربية أو الإنجليزية..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              id="search-name-input"
              style={{
                flex: 1,
                padding: '12px 16px',
                border: '1px solid var(--border-medium)',
                background: 'var(--bg-paper)',
                fontFamily: 'var(--font-arabic)',
                fontSize: '1rem',
                color: 'var(--text-primary)',
                direction: 'rtl',
                outline: 'none',
              }}
            />
            <button
              className="btn-accent"
              onClick={handleSearch}
              disabled={loading || !query.trim()}
              id="btn-search-name"
            >
              {loading ? '...' : 'بحث'}
            </button>
          </div>
        )}

        {mode === 'age' && (
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <input
              type="number"
              placeholder="العمر (مثال: 25)"
              value={ageVal}
              onChange={(e) => setAgeVal(e.target.value)}
              min={0}
              max={120}
              id="search-age-input"
              style={{
                width: 150,
                padding: '12px 16px',
                border: '1px solid var(--border-medium)',
                background: 'var(--bg-paper)',
                fontFamily: 'var(--font-arabic)',
                fontSize: '1rem',
                color: 'var(--text-primary)',
                outline: 'none',
              }}
            />
            <span style={{ fontFamily: 'var(--font-arabic)', color: 'var(--text-muted)' }}>
              (±2 سنة)
            </span>
            <button
              className="btn-accent"
              onClick={handleSearch}
              disabled={loading || !ageVal}
              id="btn-search-age"
            >
              بحث
            </button>
          </div>
        )}

        {mode === 'date' && (
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              id="search-date-from"
              style={{
                padding: '12px 16px',
                border: '1px solid var(--border-medium)',
                background: 'var(--bg-paper)',
                fontFamily: 'var(--font-mono)',
                fontSize: '0.875rem',
                outline: 'none',
              }}
            />
            <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>→</span>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              id="search-date-to"
              style={{
                padding: '12px 16px',
                border: '1px solid var(--border-medium)',
                background: 'var(--bg-paper)',
                fontFamily: 'var(--font-mono)',
                fontSize: '0.875rem',
                outline: 'none',
              }}
            />
            <button
              className="btn-accent"
              onClick={handleSearch}
              disabled={loading}
              id="btn-search-date"
            >
              بحث
            </button>
          </div>
        )}
      </div>

      {/* Algorithm info badge */}
      {result && (
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap', marginBottom: 12 }}>
            <span className="result-stamp">
              {result.count > 0 ? `وُجد ${result.count.toLocaleString('ar-EG')}` : 'لم يُوجد'}
            </span>
            <div className="algorithm-badge green">
              {result.algorithm}
            </div>
            <span className="complexity-tag">{result.complexity}</span>
            {result.comparisons !== undefined && (
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '11px', color: 'var(--text-muted)' }}>
                {result.comparisons.toLocaleString()} مقارنة
              </span>
            )}
          </div>

          {/* Results list */}
          {result.results.length > 0 && (
            <div style={{ borderTop: '1px solid var(--border-subtle)' }}>
              {result.results.slice(0, 20).map((rec, i) => (
                <div key={rec.id || i} className="archive-row">
                  <span className="archive-row-number">{String(i + 1).padStart(3, '0')}</span>
                  <span className="archive-row-name-ar">{rec.ar_name || rec.en_name}</span>
                  <span className="archive-row-meta">
                    {rec.age != null ? `${rec.age}y` : '—'}
                    {rec.sex ? ` · ${rec.sex === 'm' ? '♂' : '♀'}` : ''}
                  </span>
                </div>
              ))}
              {result.count > 20 && (
                <p style={{
                  padding: '16px 0',
                  fontFamily: 'var(--font-mono)',
                  fontSize: '11px',
                  color: 'var(--text-muted)',
                  textAlign: 'center',
                }}>
                  ... و {(result.count - 20).toLocaleString('ar-EG')} نتيجة أخرى
                </p>
              )}
            </div>
          )}

          {result.results.length === 0 && searched && (
            <p style={{
              padding: '40px',
              textAlign: 'center',
              fontFamily: 'var(--font-arabic)',
              color: 'var(--text-muted)',
              direction: 'rtl',
            }}>
              لم يُعثر على نتائج.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
