'use client';

/**
 * ArchiveSection
 * --------------
 * Searchable, interactive memorial database of all 72,835 martyrs.
 * Natural page flow (no mouse-trapping scroll containers), instant live search,
 * category filters, and modal record preview.
 */

import { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { api } from '@/lib/api';
import { useParticleStore } from '@/lib/particleStore';
import type { Record } from '@/lib/types';

type CategoryFilter = 'all' | 'children' | 'youth' | 'elders';

export default function ArchiveSection() {
  const [records, setRecords] = useState<Record[]>([]);
  const [query, setQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<CategoryFilter>('all');
  const [isSearching, setIsSearching] = useState(false);
  const [totalMatches, setTotalMatches] = useState<number>(72835);
  const [page, setPage] = useState(1);
  const [selectedRecord, setSelectedRecord] = useState<Record | null>(null);
  const pageSize = 24;

  const { setHighlightIds, setSortMode } = useParticleStore();
  const debounceRef = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  // Fetch records based on current filters and page
  const fetchCurrentRecords = useCallback(async (targetPage = 1) => {
    setIsSearching(true);
    try {
      if (query.trim()) {
        const res = await api.searchByName(query, targetPage, pageSize);
        setRecords(res.results || []);
        setTotalMatches(res.count || 0);
        setHighlightIds((res.results || []).map((r: Record) => r.id));
      } else if (activeCategory === 'children') {
        const res = await api.searchByAge(10, 8, targetPage, pageSize);
        setRecords(res.results || []);
        setTotalMatches(res.count || 21637);
      } else if (activeCategory === 'youth') {
        const res = await api.searchByAge(25, 7, targetPage, pageSize);
        setRecords(res.results || []);
        setTotalMatches(res.count || 0);
      } else if (activeCategory === 'elders') {
        const res = await api.searchByAge(70, 15, targetPage, pageSize);
        setRecords(res.results || []);
        setTotalMatches(res.count || 0);
      } else {
        const res = await api.getRecords(targetPage, pageSize);
        setRecords(res.items || []);
        setTotalMatches(res.total || 72835);
      }
    } catch {
      // keep fallback
    } finally {
      setIsSearching(false);
    }
  }, [query, activeCategory, setHighlightIds]);

  // Handle Search Input
  useEffect(() => {
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setPage(1);
      fetchCurrentRecords(1);
    }, 350);

    return () => clearTimeout(debounceRef.current);
  }, [query, fetchCurrentRecords]);

  // Handle Category Filter Change
  const handleCategory = (cat: CategoryFilter) => {
    setActiveCategory(cat);
    setQuery('');
    setPage(1);
  };

  const handlePageChange = (newPage: number) => {
    setPage(newPage);
    fetchCurrentRecords(newPage);
    const archiveEl = document.getElementById('archive');
    if (archiveEl) {
      const top = archiveEl.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  };

  // Quick Sort handler
  const handleSort = useCallback(async (type: 'name' | 'age') => {
    setIsSearching(true);
    try {
      if (type === 'name') {
        setSortMode('name', true);
        const res = await api.sortByName(true, 1, pageSize);
        setRecords(res.results || []);
      } else {
        setSortMode('age', true);
        const res = await api.sortByAge(true, 1, pageSize);
        setRecords(res.results || []);
      }
    } finally {
      setIsSearching(false);
    }
  }, [setSortMode]);

  const totalPages = Math.max(1, Math.ceil(totalMatches / pageSize));

  return (
    <section
      id="archive"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
        padding: '100px 24px 80px',
        direction: 'rtl',
      }}
    >
      <div style={{ maxWidth: '1140px', width: '100%' }}>
        {/* Section Header */}
        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <span
            style={{
              fontSize: '11px',
              fontFamily: "'JetBrains Mono', monospace",
              color: '#10b981',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
            }}
          >
            LIVING MEMORIAL ARCHIVE — سجل الخلود
          </span>
          <h2
            style={{
              fontSize: 'clamp(1.8rem, 4.5vw, 3rem)',
              fontWeight: 800,
              color: '#f8fafc',
              marginTop: '10px',
            }}
          >
            سجل الخلود الفلسطيني
          </h2>
          <p style={{ fontSize: '15px', color: '#94a3b8', marginTop: '8px', maxWidth: '640px', margin: '8px auto 0' }}>
            ابحث بالاسم أو العائلة لتستحضر كل شهيد كروحٍ خالدة في ضمير الأمة والوجدان الإنساني.
          </p>
        </div>

        {/* Search Input Bar */}
        <div
          style={{
            position: 'relative',
            maxWidth: '680px',
            margin: '0 auto 28px',
          }}
        >
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم، العائلة، أو اللقب (مثال: محمد، النجار، أبو حصيرة)..."
            style={{
              width: '100%',
              background: 'rgba(15, 23, 42, 0.85)',
              border: '1px solid rgba(16, 185, 129, 0.4)',
              borderRadius: '20px',
              padding: '15px 52px 15px 20px',
              color: '#f8fafc',
              fontSize: '14.5px',
              outline: 'none',
              backdropFilter: 'blur(16px)',
              boxShadow: '0 10px 30px rgba(0,0,0,0.5), 0 0 20px rgba(16, 185, 129, 0.12)',
              direction: 'rtl',
              fontFamily: 'inherit',
            }}
          />
          <span
            style={{
              position: 'absolute',
              right: '18px',
              top: '50%',
              transform: 'translateY(-50%)',
              fontSize: '18px',
              color: '#34d399',
            }}
          >
            🔍
          </span>

          {query && (
            <button
              onClick={() => setQuery('')}
              style={{
                position: 'absolute',
                left: '16px',
                top: '50%',
                transform: 'translateY(-50%)',
                background: 'rgba(255,255,255,0.1)',
                border: 'none',
                borderRadius: '50%',
                width: '24px',
                height: '24px',
                color: '#94a3b8',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '12px',
              }}
            >
              ✕
            </button>
          )}
        </div>

        {/* Filter Chips & Sort Controls */}
        <div
          style={{
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            alignItems: 'center',
            gap: '16px',
            marginBottom: '32px',
          }}
        >
          {/* Categories */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {[
              { id: 'all', label: 'كل السجلات' },
              { id: 'children', label: 'الأطفال (دون 18)' },
              { id: 'youth', label: 'الشباب (18-35)' },
              { id: 'elders', label: 'كبار السن (60+)' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleCategory(cat.id as CategoryFilter)}
                style={{
                  background:
                    activeCategory === cat.id
                      ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
                      : 'rgba(255, 255, 255, 0.05)',
                  border: activeCategory === cat.id ? 'none' : '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '999px',
                  padding: '7px 16px',
                  color: activeCategory === cat.id ? '#ffffff' : '#cbd5e1',
                  fontSize: '12.5px',
                  fontWeight: 600,
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                }}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Sort Buttons & Count */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ fontSize: '13px', color: '#94a3b8' }}>
              المطابقات: <strong style={{ color: '#34d399' }}>{totalMatches.toLocaleString('ar-EG')}</strong>
            </span>

            <button
              onClick={() => handleSort('name')}
              className="btn-glass"
              style={{ fontSize: '12px', padding: '6px 14px' }}
            >
              فرز أبجدي
            </button>
            <button
              onClick={() => handleSort('age')}
              className="btn-glass"
              style={{ fontSize: '12px', padding: '6px 14px' }}
            >
              فرز عمري
            </button>
          </div>
        </div>

        {/* Results Grid — Natural Page Flow (Zero scroll interception) */}
        {isSearching ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: '#94a3b8' }}>
            <span style={{ fontSize: '24px', display: 'block', marginBottom: '12px' }}>⏳</span>
            جارٍ استحضار السجلات...
          </div>
        ) : records.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '60px 0', color: '#94a3b8' }}>
            لا توجد سجلات مطابقة لمعايير البحث الحالية.
          </div>
        ) : (
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))',
              gap: '16px',
              marginBottom: '36px',
            }}
          >
            {records.map((r) => {
              const isChild = r.age !== null && r.age !== undefined && r.age < 18;
              return (
                <motion.div
                  key={r.id}
                  whileHover={{ y: -3, borderColor: '#10b981' }}
                  onClick={() => setSelectedRecord(r)}
                  style={{
                    background: 'rgba(15, 23, 42, 0.75)',
                    border: isChild ? '1px solid rgba(245, 158, 11, 0.3)' : '1px solid rgba(255, 255, 255, 0.08)',
                    borderRadius: '16px',
                    padding: '16px',
                    backdropFilter: 'blur(12px)',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    transition: 'border-color 0.2s',
                    position: 'relative',
                    cursor: 'pointer',
                  }}
                >
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                      <span
                        style={{
                          fontSize: '15px',
                          fontWeight: 700,
                          color: '#f8fafc',
                          lineHeight: 1.3,
                        }}
                      >
                        {r.ar_name || r.en_name || 'شهيد مجهول الاسم'}
                      </span>
                      {isChild && (
                        <span
                          style={{
                            background: 'rgba(245, 158, 11, 0.2)',
                            color: '#fbbf24',
                            border: '1px solid rgba(245, 158, 11, 0.4)',
                            fontSize: '10px',
                            padding: '2px 8px',
                            borderRadius: '999px',
                            fontWeight: 700,
                            flexShrink: 0,
                          }}
                        >
                          طفل
                        </span>
                      )}
                    </div>

                    {r.en_name && (
                      <div style={{ fontSize: '11px', color: '#64748b', direction: 'ltr', textAlign: 'right' }}>
                        {r.en_name}
                      </div>
                    )}
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      marginTop: '16px',
                      paddingTop: '12px',
                      borderTop: '1px solid rgba(255, 255, 255, 0.06)',
                    }}
                  >
                    <span style={{ fontSize: '12px', color: isChild ? '#fbbf24' : '#34d399', fontWeight: 600 }}>
                      {r.age !== null && r.age !== undefined ? `${r.age} عامًا` : 'العمر غير مسجل'}
                    </span>

                    <span style={{ fontSize: '10px', fontFamily: "'JetBrains Mono', monospace", color: '#64748b' }}>
                      #{r.id}
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Clean Pagination Bar */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            gap: '12px',
            marginTop: '20px',
          }}
        >
          <button
            onClick={() => handlePageChange(page - 1)}
            disabled={page <= 1}
            className="btn-glass"
            style={{
              padding: '8px 16px',
              fontSize: '12.5px',
              opacity: page <= 1 ? 0.4 : 1,
              cursor: page <= 1 ? 'not-allowed' : 'pointer',
            }}
          >
            ← السابق
          </button>

          <span style={{ fontSize: '13px', color: '#cbd5e1' }}>
            صفحة <strong style={{ color: '#34d399' }}>{page}</strong> من <strong>{totalPages.toLocaleString('ar-EG')}</strong>
          </span>

          <button
            onClick={() => handlePageChange(page + 1)}
            disabled={page >= totalPages}
            className="btn-glass"
            style={{
              padding: '8px 16px',
              fontSize: '12.5px',
              opacity: page >= totalPages ? 0.4 : 1,
              cursor: page >= totalPages ? 'not-allowed' : 'pointer',
            }}
          >
            التالي →
          </button>
        </div>
      </div>

      {/* Detail Record Modal */}
      <AnimatePresence>
        {selectedRecord && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedRecord(null)}
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 9999,
              background: 'rgba(0, 0, 0, 0.75)',
              backdropFilter: 'blur(10px)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '24px',
            }}
          >
            <motion.div
              initial={{ scale: 0.92, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.92, y: 20 }}
              onClick={(e) => e.stopPropagation()}
              style={{
                maxWidth: '480px',
                width: '100%',
                background: 'rgba(15, 23, 42, 0.96)',
                border: '1px solid rgba(16, 185, 129, 0.4)',
                borderRadius: '24px',
                padding: '32px',
                boxShadow: '0 25px 60px rgba(0, 0, 0, 0.8)',
                textAlign: 'center',
                direction: 'rtl',
              }}
            >
              <div style={{ fontSize: '11px', color: '#34d399', letterSpacing: '0.1em' }}>
                ✦ سجل شهيد في الذاكرة الوطنية ✦
              </div>

              <h3 style={{ fontSize: '24px', fontWeight: 800, color: '#f8fafc', margin: '14px 0 8px' }}>
                {selectedRecord.ar_name}
              </h3>

              {selectedRecord.en_name && (
                <div style={{ fontSize: '13px', color: '#94a3b8', direction: 'ltr', marginBottom: '20px' }}>
                  {selectedRecord.en_name}
                </div>
              )}

              <div
                style={{
                  background: 'rgba(255, 255, 255, 0.04)',
                  borderRadius: '16px',
                  padding: '16px',
                  display: 'grid',
                  gridTemplateColumns: 'repeat(2, 1fr)',
                  gap: '12px',
                  margin: '20px 0',
                  textAlign: 'right',
                }}
              >
                <div>
                  <span style={{ fontSize: '11px', color: '#64748b' }}>العمر:</span>
                  <div style={{ fontSize: '16px', fontWeight: 700, color: '#fbbf24' }}>
                    {selectedRecord.age !== null ? `${selectedRecord.age} عامًا` : 'غير مسجل'}
                  </div>
                </div>

                <div>
                  <span style={{ fontSize: '11px', color: '#64748b' }}>الجنس:</span>
                  <div style={{ fontSize: '16px', fontWeight: 700, color: '#f8fafc' }}>
                    {selectedRecord.sex === 'm' ? 'ذكر' : selectedRecord.sex === 'f' ? 'أنثى' : '—'}
                  </div>
                </div>

                <div>
                  <span style={{ fontSize: '11px', color: '#64748b' }}>تاريخ الميلاد:</span>
                  <div style={{ fontSize: '14px', color: '#cbd5e1' }}>
                    {selectedRecord.dob || 'غير متوفر'}
                  </div>
                </div>

                <div>
                  <span style={{ fontSize: '11px', color: '#64748b' }}>رقم السجل:</span>
                  <div style={{ fontSize: '14px', fontFamily: "'JetBrains Mono', monospace", color: '#34d399' }}>
                    #{selectedRecord.id}
                  </div>
                </div>
              </div>

              <button
                onClick={() => setSelectedRecord(null)}
                className="btn-emerald"
                style={{ width: '100%', marginTop: '8px' }}
              >
                إغلاق السجل
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
