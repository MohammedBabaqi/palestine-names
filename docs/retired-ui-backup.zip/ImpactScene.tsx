'use client';

/**
 * ImpactScene
 * -----------
 * The emotional heart of the memorial experience.
 * Three monumental verses appearing with poignant reverence:
 * "لم يكونوا أرقامًا."
 * "كانوا أشخاصًا."
 * "وكان لكل شخص اسم."
 */

import { motion } from 'framer-motion';

const VERSES = [
  { text: 'لم يكونوا أرقامًا.', delay: 0.1, color: '#f8fafc', size: 'clamp(2rem, 6vw, 4.2rem)', weight: 800 },
  { text: 'كانوا أشخاصًا.', delay: 0.5, color: '#6ee7b7', size: 'clamp(2rem, 6vw, 4.2rem)', weight: 800 },
  { text: 'وكان لكل شخصٍ اسمٌ وحلمٌ وأثر.', delay: 0.9, color: '#cbd5e1', size: 'clamp(1.5rem, 4.5vw, 3rem)', weight: 600 },
];

export default function ImpactScene() {
  return (
    <section
      id="impact"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
        padding: '80px 24px',
        textAlign: 'center',
        direction: 'rtl',
      }}
    >
      <div
        style={{
          maxWidth: '900px',
          width: '100%',
          background: 'rgba(10, 15, 26, 0.75)',
          border: '1px solid rgba(255, 255, 255, 0.08)',
          borderRadius: '32px',
          padding: '64px 32px',
          backdropFilter: 'blur(20px)',
          boxShadow: '0 30px 80px rgba(0,0,0,0.8), 0 0 50px rgba(16, 185, 129, 0.12)',
        }}
      >
        {/* Luminous Top Accent Dot */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginBottom: '32px' }}>
          <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#ef4444' }} />
          <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#ffffff' }} />
          <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#10b981' }} />
        </div>

        {VERSES.map((verse, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.9, delay: verse.delay, ease: [0.16, 1, 0.3, 1] }}
            style={{
              fontSize: verse.size,
              fontWeight: verse.weight,
              color: verse.color,
              lineHeight: 1.4,
              marginBottom: idx < VERSES.length - 1 ? '20px' : '0',
              fontFamily: "'IBM Plex Sans Arabic', 'Amiri', serif",
              letterSpacing: '-0.02em',
            }}
          >
            {verse.text}
          </motion.div>
        ))}

        {/* Poetic Sub-verse */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 1.2 }}
          style={{
            marginTop: '36px',
            fontSize: '15px',
            color: '#94a3b8',
            lineHeight: 1.8,
            maxWidth: '600px',
            margin: '36px auto 0',
          }}
        >
          وراء كل رقمٍ في هذه السجلات كانت هناك أم تنتظر، وطفل يبتسم، وأب يبني، وعائلة تجتمع حول موقد المساء. نحن هنا لنعيد لكل رقمٍ اسمه ونبضه.
        </motion.p>
      </div>
    </section>
  );
}
