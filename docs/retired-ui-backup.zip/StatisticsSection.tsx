'use client';

/**
 * StatisticsSection
 * -----------------
 * Powerful demographic intelligence visualization.
 * Reveals the staggering reality: 21,637 children, average age 28.7 years,
 * and the complete generational spectrum of the Palestinian martyrs.
 */

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { api } from '@/lib/api';
import type { Statistics } from '@/lib/types';

export default function StatisticsSection() {
  const [stats, setStats] = useState<Statistics | null>(null);

  useEffect(() => {
    api.getStatistics()
      .then(setStats)
      .catch(() => {});
  }, []);

  const formatNum = (n?: number | null) => (n !== null && n !== undefined ? n.toLocaleString('ar-EG') : '—');

  return (
    <section
      id="statistics"
      style={{
        position: 'relative',
        width: '100%',
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
        padding: '100px 24px',
        direction: 'rtl',
      }}
    >
      <div style={{ maxWidth: '1050px', width: '100%' }}>
        {/* Section Header */}
        <div style={{ textAlign: 'center', marginBottom: '56px' }}>
          <span
            style={{
              fontSize: '11px',
              fontFamily: "'JetBrains Mono', monospace",
              color: '#10b981',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
            }}
          >
            DEMOGRAPHIC ARCHIVE — إحصاءات الذاكرة
          </span>
          <h2
            style={{
              fontSize: 'clamp(1.8rem, 4.5vw, 3rem)',
              fontWeight: 800,
              color: '#f8fafc',
              marginTop: '12px',
            }}
          >
            الأرقام حين تنطق بالحقيقة
          </h2>
          <p style={{ fontSize: '15px', color: '#94a3b8', marginTop: '10px', maxWidth: '600px', margin: '10px auto 0' }}>
            تحليل دقيق لبيانات 72,835 شهيدًا مسجلين رسميًا، يبيّن أن الاستهداف طال الطفولة والشباب والعائلات بأسرها.
          </p>
        </div>

        {/* 4 Key Pillars Cards */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: '20px',
            marginBottom: '40px',
          }}
        >
          {/* Card 1: Total */}
          <motion.div
            whileHover={{ y: -4 }}
            style={{
              background: 'rgba(15, 23, 42, 0.75)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '20px',
              padding: '24px',
              textAlign: 'center',
              backdropFilter: 'blur(16px)',
            }}
          >
            <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>إجمالي الشهداء الموثقين</div>
            <div
              style={{
                fontSize: 'clamp(2rem, 3.5vw, 2.8rem)',
                fontWeight: 800,
                color: '#f8fafc',
                lineHeight: 1.1,
              }}
            >
              {formatNum(stats?.total || 72835)}
            </div>
            <div style={{ fontSize: '11px', color: '#6ee7b7', marginTop: '8px' }}>سجل رسمي كامل</div>
          </motion.div>

          {/* Card 2: Children Highlight */}
          <motion.div
            whileHover={{ y: -4 }}
            style={{
              background: 'linear-gradient(180deg, rgba(245, 158, 11, 0.12) 0%, rgba(15, 23, 42, 0.8) 100%)',
              border: '1px solid rgba(245, 158, 11, 0.45)',
              borderRadius: '20px',
              padding: '24px',
              textAlign: 'center',
              boxShadow: '0 8px 30px rgba(245, 158, 11, 0.15)',
              backdropFilter: 'blur(16px)',
            }}
          >
            <div style={{ fontSize: '12px', color: '#fbbf24', fontWeight: 600, marginBottom: '8px' }}>
              ✦ أطفال دون سن 18 ✦
            </div>
            <div
              style={{
                fontSize: 'clamp(2rem, 3.5vw, 2.8rem)',
                fontWeight: 800,
                color: '#fbbf24',
                lineHeight: 1.1,
              }}
            >
              {formatNum(stats?.children_under_18 || 21637)}
            </div>
            <div style={{ fontSize: '11px', color: '#fde047', marginTop: '8px' }}>
              نحو 30% من إجمالي الشهداء
            </div>
          </motion.div>

          {/* Card 3: Average Age */}
          <motion.div
            whileHover={{ y: -4 }}
            style={{
              background: 'rgba(15, 23, 42, 0.75)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              borderRadius: '20px',
              padding: '24px',
              textAlign: 'center',
              backdropFilter: 'blur(16px)',
            }}
          >
            <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>متوسط الأعمار</div>
            <div
              style={{
                fontSize: 'clamp(2rem, 3.5vw, 2.8rem)',
                fontWeight: 800,
                color: '#34d399',
                lineHeight: 1.1,
              }}
            >
              {stats?.average_age ? `${stats.average_age} عامًا` : '28.7 عامًا'}
            </div>
            <div style={{ fontSize: '11px', color: '#94a3b8', marginTop: '8px' }}>
              الوسيط: {stats?.median_age || 27} سنة
            </div>
          </motion.div>

          {/* Card 4: Age Span */}
          <motion.div
            whileHover={{ y: -4 }}
            style={{
              background: 'rgba(15, 23, 42, 0.75)',
              border: '1px solid rgba(255, 255, 255, 0.1)',
              borderRadius: '20px',
              padding: '24px',
              textAlign: 'center',
              backdropFilter: 'blur(16px)',
            }}
          >
            <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '8px' }}>نطاق الأعمار</div>
            <div
              style={{
                fontSize: 'clamp(1.5rem, 2.8vw, 2.2rem)',
                fontWeight: 800,
                color: '#f8fafc',
                lineHeight: 1.2,
                marginTop: '4px',
              }}
            >
              من {stats?.min_age ?? 0} إلى {stats?.max_age ?? 110} عامًا
            </div>
            <div style={{ fontSize: '11px', color: '#64748b', marginTop: '8px' }}>
              من رُضّع إلى معمّرين
            </div>
          </motion.div>
        </div>

        {/* Age Cohorts Visual Distribution */}
        {stats?.age_distribution && stats.age_distribution.length > 0 && (
          <div
            style={{
              background: 'rgba(11, 15, 25, 0.85)',
              border: '1px solid rgba(255, 255, 255, 0.08)',
              borderRadius: '24px',
              padding: '32px',
              backdropFilter: 'blur(20px)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
              <h3 style={{ fontSize: '16px', fontWeight: 700, color: '#f8fafc', margin: 0 }}>
                توزيع الشهداء حسب الفئات العمرية
              </h3>
              <span style={{ fontSize: '12px', color: '#94a3b8' }}>عدد الشهداء لكل عقد زمني</span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {stats.age_distribution.slice(0, 8).map((dist) => {
                const maxCount = 16500;
                const pct = Math.min((dist.count / maxCount) * 100, 100);
                const isChildCohort = dist.range === '0-9' || dist.range === '10-19';

                return (
                  <div key={dist.range} style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                    <div style={{ width: '60px', fontSize: '12px', color: '#cbd5e1', fontWeight: 600 }}>
                      {dist.range} سنة
                    </div>
                    <div
                      style={{
                        flex: 1,
                        height: '20px',
                        background: 'rgba(255, 255, 255, 0.05)',
                        borderRadius: '6px',
                        overflow: 'hidden',
                        position: 'relative',
                      }}
                    >
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${pct}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        style={{
                          height: '100%',
                          background: isChildCohort
                            ? 'linear-gradient(90deg, #f59e0b 0%, #fbbf24 100%)'
                            : 'linear-gradient(90deg, #059669 0%, #10b981 100%)',
                          borderRadius: '6px',
                        }}
                      />
                    </div>
                    <div style={{ width: '80px', fontSize: '12px', color: '#f8fafc', fontWeight: 600, textAlign: 'left' }}>
                      {dist.count.toLocaleString('ar-EG')}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
