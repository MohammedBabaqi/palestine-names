/**
 * Generates target positions for each human particle across narrative modes:
 * - 'number': human figures form the giant "72,000+"
 * - 'scatter': gentle, living cloud of souls
 * - 'names': constellation with space for calligraphy names
 * - 'stats': human figures physically gather into demographic bar towers
 * - 'sort': human figures physically arrange by age/chronology
 */

import type { Record } from './types';

export interface ParticleTarget {
  x: number;
  y: number;
  z: number;
  scale: number;
  alpha: number;
}

// ─── Seeded Pseudo-Random (deterministic across renders) ───────
function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

// ─── Number Pixel Sampler: "72,000+" ──────────────────────────
let cachedNumberPixels: Array<{ x: number; y: number }> | null = null;

export function getNumberPixels(count: number): Array<{ x: number; y: number }> {
  if (cachedNumberPixels && cachedNumberPixels.length > 0) {
    return samplePixels(cachedNumberPixels, count);
  }

  if (typeof document === 'undefined') return [];

  const canvas = document.createElement('canvas');
  const W = 900;
  const H = 320;
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#000';
  ctx.font = `800 180px "IBM Plex Sans Arabic", "Inter", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('72,000+', W / 2, H / 2);

  const imageData = ctx.getImageData(0, 0, W, H);
  const pixels: Array<{ x: number; y: number }> = [];
  const step = 2;

  for (let y = 0; y < H; y += step) {
    for (let x = 0; x < W; x += step) {
      const idx = (y * W + x) * 4;
      if (imageData.data[idx + 3] > 140) {
        // Map to 3D world space
        pixels.push({
          x: (x / W - 0.5) * 6.5,
          y: -(y / H - 0.5) * 2.8,
        });
      }
    }
  }

  cachedNumberPixels = pixels;
  return samplePixels(pixels, count);
}

function samplePixels(
  pixels: Array<{ x: number; y: number }>,
  count: number
): Array<{ x: number; y: number }> {
  if (pixels.length === 0) return [];
  const result: Array<{ x: number; y: number }> = [];
  for (let i = 0; i < count; i++) {
    result.push(pixels[Math.floor(Math.random() * pixels.length)]);
  }
  return result;
}

// ─── Mode 1: Number Formation ─────────────────────────────────
export function computeNumberPositions(
  count: number,
  numberPixels: Array<{ x: number; y: number }>
): ParticleTarget[] {
  const rand = seededRandom(101);
  const targets: ParticleTarget[] = [];
  const pxList = numberPixels.length > 0 ? numberPixels : [{ x: 0, y: 0 }];

  for (let i = 0; i < count; i++) {
    const px = pxList[i % pxList.length];
    targets.push({
      x: px.x + (rand() - 0.5) * 0.06,
      y: px.y + (rand() - 0.5) * 0.06,
      z: (rand() - 0.5) * 0.12,
      scale: 0.55 + rand() * 0.25,
      alpha: 0.9,
    });
  }
  return targets;
}

// ─── Mode 2: The Living Crowd (Scatter Field) ──────────────────
export function computeScatterPositions(count: number): ParticleTarget[] {
  const rand = seededRandom(42);
  const targets: ParticleTarget[] = [];

  for (let i = 0; i < count; i++) {
    // Elegant elliptical layered cloud
    const r = Math.pow(rand(), 0.6) * 5.2;
    const angle = rand() * Math.PI * 2;
    const heightSpread = (rand() - 0.5) * 3.4;
    const depthSpread = (rand() - 0.5) * 3.0;

    targets.push({
      x: Math.cos(angle) * r,
      y: heightSpread,
      z: depthSpread,
      scale: 0.5 + rand() * 0.45,
      alpha: 0.75 + rand() * 0.25,
    });
  }
  return targets;
}

// ─── Mode 3: Space for Names ──────────────────────────────────
export function computeNamesPositions(count: number): ParticleTarget[] {
  const rand = seededRandom(88);
  const targets: ParticleTarget[] = [];

  for (let i = 0; i < count; i++) {
    const r = 2.2 + rand() * 3.8;
    const angle = (i / count) * Math.PI * 2 + (rand() - 0.5) * 0.5;
    targets.push({
      x: Math.cos(angle) * r,
      y: (rand() - 0.5) * 2.8,
      z: (rand() - 0.5) * 2.0,
      scale: 0.5 + rand() * 0.4,
      alpha: 0.7,
    });
  }
  return targets;
}

// ─── Mode 4: Physical Demographic Statistics (People become the bars) ─
export function computeStatsPositions(
  records: Record[],
  count: number
): ParticleTarget[] {
  // 6 Age groups: 0-9, 10-19, 20-29, 30-39, 40-59, 60+
  const groupCount = 6;
  const rand = seededRandom(19);
  const targets: ParticleTarget[] = [];

  // Group ratios based on dataset:
  // 0-9: ~15%, 10-19: ~20%, 20-29: ~22%, 30-39: ~20%, 40-59: ~16%, 60+: ~7%
  const groupWeights = [0.15, 0.20, 0.22, 0.20, 0.16, 0.07];
  const barWidth = 0.65;
  const startX = -3.2;
  const stepX = 1.3;

  for (let i = 0; i < count; i++) {
    // Distribute according to real demographic proportion
    let groupIdx = 0;
    const p = i / count;
    let accum = 0;
    for (let g = 0; g < groupWeights.length; g++) {
      accum += groupWeights[g];
      if (p <= accum) {
        groupIdx = g;
        break;
      }
    }

    const colX = startX + groupIdx * stepX + (rand() - 0.5) * barWidth;
    const maxHeight = groupWeights[groupIdx] * 12.0;
    const colY = -1.6 + rand() * maxHeight;
    const colZ = (rand() - 0.5) * 0.4;

    targets.push({
      x: colX,
      y: colY,
      z: colZ,
      scale: 0.48,
      alpha: 0.85,
    });
  }
  return targets;
}

// ─── Mode 5: Physical Sort (People lined up by age) ───────────
export function computeSortPositions(
  records: Record[],
  count: number
): ParticleTarget[] {
  const rand = seededRandom(73);
  const targets: ParticleTarget[] = [];

  for (let i = 0; i < count; i++) {
    // Line up from infant (left) to centenarian (right)
    const norm = i / count;
    const x = (norm - 0.5) * 7.5;
    const arcY = Math.sin(norm * Math.PI) * 0.8 - 0.4;
    const y = arcY + (rand() - 0.5) * 0.4;
    const z = (rand() - 0.5) * 0.6;

    targets.push({
      x,
      y,
      z,
      scale: 0.45 + (1 - norm) * 0.25, // Children slightly distinct
      alpha: 0.8,
    });
  }
  return targets;
}
