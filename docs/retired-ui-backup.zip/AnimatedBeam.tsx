'use client';

/**
 * AnimatedBeam (Magic UI pattern — implemented locally)
 * Draws an animated SVG path (beam of light) between two ref elements.
 * Used in ArchivistSection to show query → processing → response.
 */

import { useEffect, useRef, useState } from 'react';

interface AnimatedBeamProps {
  containerRef: React.RefObject<HTMLElement | null>;
  fromRef: React.RefObject<HTMLElement | null>;
  toRef: React.RefObject<HTMLElement | null>;
  curvature?: number;
  reverse?: boolean;
  duration?: number;
  delay?: number;
  pathColor?: string;
  pathWidth?: number;
  pathOpacity?: number;
  gradientStartColor?: string;
  gradientStopColor?: string;
  startXOffset?: number;
  startYOffset?: number;
  endXOffset?: number;
  endYOffset?: number;
}

function getRelativePos(container: HTMLElement, el: HTMLElement) {
  const containerRect = container.getBoundingClientRect();
  const elRect = el.getBoundingClientRect();
  return {
    x: elRect.left - containerRect.left + elRect.width / 2,
    y: elRect.top - containerRect.top + elRect.height / 2,
  };
}

export default function AnimatedBeam({
  containerRef,
  fromRef,
  toRef,
  curvature = 0,
  reverse = false,
  duration = 3,
  delay = 0,
  pathColor = 'rgba(0,98,51,0.15)',
  pathWidth = 2,
  pathOpacity = 0.6,
  gradientStartColor = 'rgba(0,98,51,0)',
  gradientStopColor = '#006233',
  startXOffset = 0,
  startYOffset = 0,
  endXOffset = 0,
  endYOffset = 0,
}: AnimatedBeamProps) {
  const svgRef = useRef<SVGSVGElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const [svgDimensions, setSvgDimensions] = useState({ width: 0, height: 0 });
  const [pathD, setPathD] = useState('');
  const gradientId = useRef(`beam-gradient-${Math.random().toString(36).slice(2)}`);

  useEffect(() => {
    const update = () => {
      if (!containerRef.current || !fromRef.current || !toRef.current || !svgRef.current) return;
      const container = containerRef.current;
      const from = getRelativePos(container, fromRef.current);
      const to = getRelativePos(container, toRef.current);

      const { width, height } = container.getBoundingClientRect();
      setSvgDimensions({ width, height });

      const sx = from.x + startXOffset;
      const sy = from.y + startYOffset;
      const ex = to.x + endXOffset;
      const ey = to.y + endYOffset;

      const midX = (sx + ex) / 2;
      const midY = (sy + ey) / 2 + curvature;

      setPathD(`M ${sx},${sy} Q ${midX},${midY} ${ex},${ey}`);
    };

    update();
    const observer = new ResizeObserver(update);
    if (containerRef.current) observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, [containerRef, fromRef, toRef, curvature, startXOffset, startYOffset, endXOffset, endYOffset]);

  const pathLength = pathRef.current?.getTotalLength() ?? 200;

  return (
    <svg
      ref={svgRef}
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        overflow: 'visible',
      }}
    >
      <defs>
        <linearGradient
          id={gradientId.current}
          gradientUnits="userSpaceOnUse"
          x1="0%"
          x2="100%"
        >
          <stop offset="0%" stopColor={gradientStartColor} stopOpacity="0" />
          <stop offset="50%" stopColor={gradientStopColor} stopOpacity="1" />
          <stop offset="100%" stopColor={gradientStartColor} stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* Static path */}
      <path
        d={pathD}
        fill="none"
        stroke={pathColor}
        strokeWidth={pathWidth}
        strokeOpacity={pathOpacity}
      />
      {/* Animated gradient stroke */}
      <path
        ref={pathRef}
        d={pathD}
        fill="none"
        stroke={`url(#${gradientId.current})`}
        strokeWidth={pathWidth}
        strokeLinecap="round"
        style={{
          strokeDasharray: pathLength,
          strokeDashoffset: reverse ? -pathLength : pathLength,
          animation: `beam-flow ${duration}s linear ${delay}s infinite`,
        }}
      />
      <style>{`
        @keyframes beam-flow {
          0%   { stroke-dashoffset: ${reverse ? -pathLength : pathLength}; }
          100% { stroke-dashoffset: ${reverse ? pathLength : -pathLength}; }
        }
      `}</style>
    </svg>
  );
}
